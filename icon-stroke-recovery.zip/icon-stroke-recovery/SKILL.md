---
name: icon-stroke-recovery
description: 把经过 outline stroke 的 SVG 图标（fill 闭合轮廓）反解回带 stroke 宽度的线稿。适用于「逆向描边」「轮廓转描边」「outline stroke 反解」「fill 转 stroke」「图标改线宽」「把图标还原成可编辑的描边」等请求，也用于一批图标统一线宽与端点样式。输出可继续编辑 stroke-width / linecap / linejoin 的 SVG，并做像素级几何验收。
agent_created: true
---

# 图标描边还原（icon-stroke-recovery）

## 适用场景

- 拿到一个 fill 的 SVG 图标，肉眼能看出它原本是"线 + 描边"，只是被 outline stroke 转成了闭合图形
- 需要改线宽、改端头（圆头/平头）、改拐角圆角
- 一批图标要统一线宽或统一端点风格
- 用户说"这个 icon 没法改粗细"、"帮我把它变回线条"

不适用：真正的实心图形（logo、色块、插画）。判断方法是先跑 `analyze.py`：如果一个子路径既不是圆点也不是圆环、也没有平行长边，那多半是实心图形，如实告诉用户无法还原。

## 原理

outline stroke 的结果就是原描边的**等距偏移包络**（Minkowski 和）。逆向只需拆出四件事：

| 要还原的 | 在包络里的表现 |
|---|---|
| 中线（原 path） | 内外两条边界的"中位线" |
| 线宽 stroke-width | 两条平行边界的间距；或圆头两端点的间距 |
| 端头 linecap | 端头是半径 = 线宽/2 的半圆（round），还是直线切口（butt） |
| 拐角 linejoin | 外拐点是半径 = 线宽/2 的圆弧（round），还是尖角（miter） |

## 工作流

### 1. 测量

```bash
python3 scripts/analyze.py icon.svg
```

脚本把每个子路径分类，并直接给出建议 path：

- `圆点` → 中心 + 直径，给零长度线段写法
- `圆环` → 圆心 / 中线 R / 线宽 / 缺口角度 / 两个端点坐标，给 `M…A…` 写法
- `折线轮廓` → 疑似线宽、端点（已是中线坐标）、长直边、全部顶点，需要人工组中心线

机器可读输出加 `--json`（批量处理用）。

### 2. 判读与组装

读数规则、组装方法、陷阱清单见 `references/geometry-rules.md`。先读它再动手，里面有几条判据（尤其"圆头端点坐标怎么取"）必须照做。

### 3. 写 stroke 版

输出文件的固定形态：

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
  <g stroke="currentColor" stroke-width="2.76" stroke-linecap="round" stroke-linejoin="round">
    <path d="…"/>   <!-- 主线 -->
  </g>
  <g stroke="currentColor" stroke-linecap="round">
    <path d="M14.92 1.78h.01" stroke-width="2.37"/>   <!-- 圆点：零长度线段 -->
  </g>
</svg>
```

- 根上 `fill="none"`，颜色用 `currentColor`
- 同线宽的图形合并到一个 `<g>`，只在差异处覆盖 `stroke-width`
- 圆点一律用「零长度线段 + round cap」，`stroke-width` 即直径。**不要**写成描边的 `<circle>`（会变空心圈）；长度写 `h.01` 而非 `h0`，避免部分工具导入时丢弃零长度子路径
- 坐标保留 3~4 位小数即可，不要为了贴合原稿写到 6 位（原稿自身有 ±0.05 抖动）

### 4. 验收（必做）

```bash
python3 scripts/verify.py 原稿.svg 新稿.svg --page
```

无头渲染两张位图做像素比对：

- `IoU` 墨迹交并比 —— **≥ 99.0% 通过**
- `轮廓偏离 max` 双方轮廓最远偏离（viewBox 单位）—— **≤ 0.08 通过**
- 面积差（正常在 ±0.5% 内）

`--page` 额外生成并排对比图，交付时给用户看一眼。未通过就回第 2 步复核，优先怀疑线宽、端点坐标、圆心。

**别把 IoU 99% 当成"形状不对"**：原稿的圆多为贝塞尔近似，边缘本身有 0.02~0.05 抖动，99.2% 通常已是极限；反之 IoU < 98% 一定是结构错了（缺口角度、端点位置、半径）。

### 5. 交付

只说明四组数字：中线半径 / 线宽、缺口角度、端点坐标、圆点尺寸是否统一。若原稿里同类元素尺寸有肉眼可见差异（例如一串渐变的圆点），先按原样保留并在说明里点出来，让用户决定是否统一，不要擅自归一。

## 脚本

| 文件 | 作用 |
|---|---|
| `scripts/analyze.py` | 测量 + 分类 + 生成建议 path。`--json` 输出结构化结果 |
| `scripts/verify.py` | 像素级验收（IoU / 轮廓偏离 / 面积差），可出对比图。依赖本机 Chrome |
| `scripts/svgpath.py` | 几何库：path 解析、展平、圆/环拟合、端点检测。批量处理时直接 import |
| `scripts/pngread.py` | 纯标准库 PNG 解码（verify 用） |

无第三方依赖；`verify.py` 需要本机有 Chrome/Chromium/Edge，找不到会明确报错并返回退出码 2。

## 常见坑

- **端点坐标取错**：圆头的"端点"不是包络尖端，而是两个边缘端点的中点。差半个线宽（1.4 个单位）在 24px 图标里非常明显
- **用一个 stroke-width 硬套所有元素**：圆点直径常与主线宽不同（甚至渐变），先测量再决定
- **忘了 transform**：文件里若有 `transform`，坐标不是最终坐标，先在 Figma/Illustrator 里展开再导出
- **把实心图形当描边还原**：会得到一堆无意义的线。先看 `analyze.py` 的分类结果
- **闭合路径的 Z**：部分图标把端点画在同一位置（`Z` 顺手闭合），此时端点会被识别成"平头"，属正常
