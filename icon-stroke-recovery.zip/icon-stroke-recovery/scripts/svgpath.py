"""SVG path 解析与几何工具（纯标准库，无第三方依赖）。

供 analyze.py / verify.py 复用。核心能力：
  - parse_path(d)        解析 path 数据为子路径（支持 M L H V C S Q T A Z，绝对+相对）
  - flatten(sp)          把子路径展平成折线，同时记录"顶点"（线段端点）的下标
  - fit_circle(pts)      最小二乘拟合圆（Kasa 法）
  - fit_ring(pts)        拟合圆环（内/外双圆），返回圆心/中线半径/线宽
  - straight_runs(sp)    找出近直线的长边（用于反推折线轮廓的中线）
  - Arc / 坐标工具        生成圆弧 path、极坐标换算
"""

import math
import re

TOKEN = re.compile(r"[MmLlHhVvCcSsQqTtAaZz]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?")
ARGC = {"M": 2, "L": 2, "H": 1, "V": 1, "C": 6, "S": 4, "Q": 4, "T": 2, "A": 7, "Z": 0}


class SubPath:
    """一条子路径。segs 为 ('L'|'C'|'A'|'Z', ...) 列表。"""

    def __init__(self):
        self.segs = []
        self.start = (0.0, 0.0)
        self.closed = False

    def __repr__(self):
        return "<SubPath %d segs closed=%s>" % (len(self.segs), self.closed)


def parse_path(d):
    """把 path 的 d 属性解析成 [SubPath]。"""
    tokens = TOKEN.findall(d)
    subs = []
    cur = None
    pos = (0.0, 0.0)
    start = (0.0, 0.0)
    cmd = None
    i = 0

    def num():
        nonlocal i
        i += 1
        return float(tokens[i - 1])

    while i < len(tokens):
        t = tokens[i]
        if re.match(r"[A-Za-z]", t):
            cmd = t
            i += 1
            if cmd in "Zz":
                if cur is not None:
                    cur.segs.append(("Z", pos, start))
                    cur.closed = True
                    pos = start
                continue
        if cmd is None:
            break
        rel = cmd.islower()
        C = cmd.upper()

        if C == "M":
            x, y = num(), num()
            if rel:
                x, y = x + pos[0], y + pos[1]
            cur = SubPath()
            cur.start = (x, y)
            cur.segs.append(("M", (x, y)))
            subs.append(cur)
            pos = (x, y)
            start = pos
            cmd = "l" if rel else "L"  # 后续隐式坐标视为 lineto
            continue

        if cur is None:
            cur = SubPath()
            subs.append(cur)

        if C == "L":
            x, y = num(), num()
            if rel:
                x, y = x + pos[0], y + pos[1]
            cur.segs.append(("L", pos, (x, y)))
            pos = (x, y)
        elif C == "H":
            x = num()
            x = x + pos[0] if rel else x
            cur.segs.append(("L", pos, (x, pos[1])))
            pos = (x, pos[1])
        elif C == "V":
            y = num()
            y = y + pos[1] if rel else y
            cur.segs.append(("L", pos, (pos[0], y)))
            pos = (pos[0], y)
        elif C == "C":
            a, b, c, e, f, g = [num() for _ in range(6)]
            if rel:
                a, b = a + pos[0], b + pos[1]
                c, e = c + pos[0], e + pos[1]
                f, g = f + pos[0], g + pos[1]
            cur.segs.append(("C", pos, (a, b), (c, e), (f, g)))
            pos = (f, g)
        elif C in ("S", "Q", "T"):
            # 少见于设计工具导出的图标，按二次/平滑曲线近似处理
            if C == "S":
                a, b, c, e = [num() for _ in range(4)]
                if rel:
                    a, b, c, e = a + pos[0], b + pos[1], c + pos[0], e + pos[1]
                cur.segs.append(("C", pos, pos, (a, b), (c, e)))
                pos = (c, e)
            else:
                cnt = 4 if C == "Q" else 2
                vals = [num() for _ in range(cnt)]
                if rel:
                    vals = [vals[k] + pos[k % 2] for k in range(cnt)]
                end = (vals[-2], vals[-1])
                ctrl = (vals[0], vals[1]) if C == "Q" else ((pos[0] + end[0]) / 2, (pos[1] + end[1]) / 2)
                c1 = (pos[0] + 2 / 3 * (ctrl[0] - pos[0]), pos[1] + 2 / 3 * (ctrl[1] - pos[1]))
                c2 = (end[0] + 2 / 3 * (ctrl[0] - end[0]), end[1] + 2 / 3 * (ctrl[1] - end[1]))
                cur.segs.append(("C", pos, c1, c2, end))
                pos = end
        elif C == "A":
            rx, ry, rot, laf, sf, x, y = [num() for _ in range(7)]
            if rel:
                x, y = x + pos[0], y + pos[1]
            cur.segs.append(("A", pos, rx, ry, rot, laf, sf, (x, y)))
            pos = (x, y)
        else:
            i += 1
    return subs


def _bez(p0, p1, p2, p3, t):
    mt = 1 - t
    return (
        mt ** 3 * p0[0] + 3 * mt * mt * t * p1[0] + 3 * mt * t * t * p2[0] + t ** 3 * p3[0],
        mt ** 3 * p0[1] + 3 * mt * mt * t * p1[1] + 3 * mt * t * t * p2[1] + t ** 3 * p3[1],
    )


def arc_points(p0, rx, ry, rot, laf, sf, p1, n=48):
    """端点参数化的椭圆弧 → 采样点（不含起点）。"""
    if rx == 0 or ry == 0 or p0 == p1:
        return [p1]
    phi = math.radians(rot)
    cosp, sinp = math.cos(phi), math.sin(phi)
    dx2, dy2 = (p0[0] - p1[0]) / 2, (p0[1] - p1[1]) / 2
    x1 = cosp * dx2 + sinp * dy2
    y1 = -sinp * dx2 + cosp * dy2
    rx, ry = abs(rx), abs(ry)
    lam = x1 * x1 / (rx * rx) + y1 * y1 / (ry * ry)
    if lam > 1:
        rx *= math.sqrt(lam)
        ry *= math.sqrt(lam)
    num = rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1
    den = rx * rx * y1 * y1 + ry * ry * x1 * x1
    co = math.sqrt(max(0.0, num / den)) if den else 0.0
    if laf == sf:
        co = -co
    cx1 = co * rx * y1 / ry
    cy1 = -co * ry * x1 / rx
    cx = cosp * cx1 - sinp * cy1 + (p0[0] + p1[0]) / 2
    cy = sinp * cx1 + cosp * cy1 + (p0[1] + p1[1]) / 2

    def ang(ux, uy, vx, vy):
        d = (ux * vx + uy * vy) / (math.hypot(ux, uy) * math.hypot(vx, vy))
        a = math.acos(max(-1.0, min(1.0, d)))
        return -a if ux * vy - uy * vx < 0 else a

    t1 = ang(1, 0, (x1 - cx1) / rx, (y1 - cy1) / ry)
    dt = ang((x1 - cx1) / rx, (y1 - cy1) / ry, (-x1 - cx1) / rx, (-y1 - cy1) / ry)
    if sf == 0 and dt > 0:
        dt -= 2 * math.pi
    elif sf == 1 and dt < 0:
        dt += 2 * math.pi
    out = []
    for k in range(1, n + 1):
        t = t1 + dt * k / n
        x = cosp * rx * math.cos(t) - sinp * ry * math.sin(t) + cx
        y = sinp * rx * math.cos(t) + cosp * ry * math.sin(t) + cy
        out.append((x, y))
    return out


def flatten(sp, dense=28):
    """展平为折线。返回 (points, vertex_idx)；vertex_idx 指向每段端点（含起点）。"""
    pts = []
    vidx = []
    if not sp.segs:
        return pts, vidx
    first = sp.segs[0]
    if first[0] == "M":
        pts.append(first[1])
        vidx.append(0)
    for seg in sp.segs:
        kind = seg[0]
        if kind in ("M", "Z"):
            if kind == "Z":
                pts.append(seg[2])
                vidx.append(len(pts) - 1)
            continue
        p0 = seg[1]
        if kind == "L":
            p1 = seg[2]
            pts.append(p1)
        elif kind == "C":
            _, _, c1, c2, p1 = seg
            approx = (math.dist(p0, c1) + math.dist(c1, c2) + math.dist(c2, p1)) / 2
            n = max(8, min(96, int(approx * dense / 4)))
            for k in range(1, n + 1):
                pts.append(_bez(p0, c1, c2, p1, k / n))
        else:  # A
            _, _, rx, ry, rot, laf, sf, p1 = seg
            n = 48
            for p in arc_points(p0, rx, ry, rot, laf, sf, p1, n):
                pts.append(p)
        vidx.append(len(pts) - 1)
    return pts, vidx


def bbox(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def fit_circle(pts):
    """Kasa 最小二乘拟合。返回 (cx, cy, r, rms)。"""
    n = len(pts)
    if n < 3:
        return 0.0, 0.0, 0.0, 0.0
    sx = sy = sxx = syy = sxy = sxz = syz = sz = 0.0
    for x, y in pts:
        z = x * x + y * y
        sx += x
        sy += y
        sxx += x * x
        syy += y * y
        sxy += x * y
        sxz += x * z
        syz += y * z
        sz += z
    A = [[sxx, sxy, sx], [sxy, syy, sy], [sx, sy, float(n)]]
    b = [sxz, syz, sz]
    M = [row[:] + [b[k]] for k, row in enumerate(A)]
    for c in range(3):
        piv = max(range(c, 3), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-12:
            return 0.0, 0.0, 0.0, 1e9
        M[c], M[piv] = M[piv], M[c]
        for r in range(3):
            if r != c:
                f = M[r][c] / M[c][c]
                for k in range(c, 4):
                    M[r][k] -= f * M[c][k]
    a = M[0][3] / M[0][0]
    bb = M[1][3] / M[1][1]
    cc = M[2][3] / M[2][2]
    cx, cy = a / 2, bb / 2
    r2 = cc + cx * cx + cy * cy
    if r2 <= 0:
        return cx, cy, 0.0, 1e9
    r = math.sqrt(r2)
    rms = math.sqrt(sum((math.hypot(x - cx, y - cy) - r) ** 2 for x, y in pts) / n)
    return cx, cy, r, rms


def fit_ring(pts, iters=8, trim=0.25):
    """拟合圆环（同心的内/外双圆）。返回 dict(cx, cy, r_in, r_out, r, w, rms)。

    做法：整体拟合取粗圆心 → 半径 2-means 分簇 → 各自最小二乘拟合 →
    剔除「端点圆弧」上的中间点（残差远离两圆）后重拟合 → 迭代收敛。

    不剔除这些点会把内/外径都往中线拉偏（实测能把 2.76 的线宽算成 2.67），
    所以这一步对线宽精度是必要的。
    """
    cx, cy, r0, _ = fit_circle(pts)
    if r0 <= 0:
        return None
    rs = [math.hypot(x - cx, y - cy) for x, y in pts]
    lo, hi = min(rs), max(rs)
    inner_pts, outer_pts = [], []
    for _ in range(iters):
        mid = (lo + hi) / 2
        inner_pts = [p for p, rr in zip(pts, rs) if rr <= mid]
        outer_pts = [p for p, rr in zip(pts, rs) if rr > mid]
        if len(inner_pts) < 6 or len(outer_pts) < 6:
            return None
        w = hi - lo
        keep_in = [p for p in inner_pts
                   if abs(math.hypot(p[0] - cx, p[1] - cy) - lo) < trim * w or w <= 0]
        keep_out = [p for p in outer_pts
                    if abs(math.hypot(p[0] - cx, p[1] - cy) - hi) < trim * w or w <= 0]
        if len(keep_in) >= 6 and len(keep_out) >= 6:
            c1 = fit_circle(keep_in)
            c2 = fit_circle(keep_out)
            ncx, ncy = (c1[0] + c2[0]) / 2, (c1[1] + c2[1]) / 2
            rs = [math.hypot(x - ncx, y - ncy) for x, y in pts]
            mid = (c1[2] + c2[2]) / 2
            ii = [rr for rr in rs if rr <= mid]
            oo = [rr for rr in rs if rr > mid]
            if not ii or not oo:
                return None
            # 用剔除端点后的子集重算内/外径，避免端点圆弧污染
            ri = [math.hypot(p[0] - ncx, p[1] - ncy) for p in keep_in]
            ro = [math.hypot(p[0] - ncx, p[1] - ncy) for p in keep_out]
            cx, cy = ncx, ncy
            lo, hi = sum(ri) / len(ri), sum(ro) / len(ro)
        else:
            return None
    rs = [math.hypot(x - cx, y - cy) for x, y in pts]
    rms = math.sqrt(sum(min((rr - lo) ** 2, (rr - hi) ** 2) for rr in rs) / len(rs))
    return {"cx": cx, "cy": cy, "r_in": lo, "r_out": hi,
            "r": (lo + hi) / 2, "w": hi - lo, "rms": rms}


def polyline_len(pts):
    return sum(math.dist(pts[k], pts[k + 1]) for k in range(len(pts) - 1))


def straight_runs(sp, min_len=0.0):
    """返回近直线段：[(p0, p1, length)]。判定标准：段端点连线长度 ≈ 曲线弧长。"""
    out = []
    for seg in sp.segs:
        if seg[0] == "L":
            p0, p1 = seg[1], seg[2]
            L = math.dist(p0, p1)
            if L >= min_len:
                out.append((p0, p1, L))
        elif seg[0] == "C":
            _, p0, c1, c2, p3 = seg
            chord = math.dist(p0, p3)
            arc = (math.dist(p0, c1) + math.dist(c1, c2) + math.dist(c2, p3)) / 2
            if chord > min_len and abs(arc - chord) < 0.02 * chord:
                out.append((p0, p3, chord))
    return out


def poly(center, r, deg):
    """极坐标 → 直角坐标（数学角：0°=右，90°=上）。"""
    return (center[0] + r * math.cos(math.radians(deg)),
            center[1] - r * math.sin(math.radians(deg)))


def angle_of(center, p):
    """点相对圆心的数学角（度，0=右，90=上）。"""
    return math.degrees(math.atan2(center[1] - p[1], p[0] - center[0]))
