"""几何验收：把「原稿 fill」与「逆向 stroke」渲染成同尺寸位图，量化比对。

用法:
    python3 verify.py 原稿.svg 逆向.svg                # 只输出指标
    python3 verify.py 原稿.svg 逆向.svg --page out.html # 附带并排对比页 + PNG

指标:
    IoU        墨迹面积交并比（>99% 视为通过）
    Hausdorff  双方轮廓最远偏离（单位=viewBox 单位，≤0.08 视为通过）
    Δarea      墨迹面积相对差

退出码: 0 = 通过, 1 = 未通过, 2 = 环境问题（找不到浏览器等）
"""

import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

from pngread import luminance_mask

CHROMES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "google-chrome", "chromium", "chromium-browser", "microsoft-edge",
]


def find_chrome():
    for c in CHROMES:
        if os.path.sep in c:
            if os.path.exists(c):
                return c
        else:
            p = shutil.which(c)
            if p:
                return p
    return None


def svg_viewbox(path):
    try:
        root = ET.parse(path).getroot()
        vb = root.get("viewBox")
        if vb:
            return [float(v) for v in re.split(r"[,\s]+", vb.strip()) if v]
        w = float(re.sub(r"[a-z%]", "", root.get("width", "24")))
        h = float(re.sub(r"[a-z%]", "", root.get("height", "24")))
        return [0.0, 0.0, w, h]
    except Exception:
        txt = open(path, encoding="utf-8", errors="ignore").read()
        m = re.search(r'viewBox\s*=\s*"([^"]+)"', txt)
        if m:
            return [float(v) for v in re.split(r"[,\s]+", m.group(1).strip()) if v]
        return [0.0, 0.0, 24.0, 24.0]


def embed(path, vb, pad=1.0):
    """把整个 svg 文件作为嵌套 <svg> 内联，保留它自己的 fill/stroke 语义。"""
    txt = open(path, encoding="utf-8", errors="ignore").read()
    body = txt[txt.index("<svg"):txt.rindex("</svg>") + 6]
    open_tag_end = body.index(">")
    head = body[4:open_tag_end]
    head = re.sub(r'\s(width|height|x|y|style|viewBox|overflow)\s*=\s*"[^"]*"', "", head)
    inner = body[open_tag_end + 1:body.rindex("</svg>")]
    x, y, w, h = vb
    return ('<svg x="%g" y="%g" width="%g" height="%g" viewBox="%g %g %g %g"%s>%s</svg>'
            % (x, y, w, h, x, y, w, h, head, inner))


def shell(vb, body, pad=1.0, size=780):
    return ('<html><meta charset="utf-8"><body style="margin:0;background:#fff;overflow:hidden">'
            '<svg viewBox="%g %g %g %g" width="%d" height="%d">%s</svg></body></html>'
            % (vb[0] - pad, vb[1] - pad, vb[2] + 2 * pad, vb[3] + 2 * pad, size, size, body))


def page_html(vb, a_path, b_path, size=300, pad=1.0):
    box = "%g %g %g %g" % (vb[0] - pad, vb[1] - pad, vb[2] + 2 * pad, vb[3] + 2 * pad)

    def fig(inner, label):
        return ('<figure style="margin:0;display:inline-block;text-align:center;vertical-align:top">'
                '<svg viewBox="%s" width="%d" height="%d" style="background:#fff;display:block">'
                '%s</svg><figcaption style="font:12px/1.7 -apple-system,PingFang SC,sans-serif;'
                'color:#666">%s</figcaption></figure>' % (box, size, size, inner, label))

    return ("<!doctype html><meta charset='utf-8'><body style='margin:0;background:#fff;"
            "white-space:nowrap'>" + fig(embed(a_path, vb), "原稿 fill")
            + fig(embed(b_path, vb), "逆向 stroke") + "</body>")


def render(chrome, html_path, out_png, size, workdir):
    subprocess.run([chrome, "--headless=new", "--no-sandbox", "--disable-gpu",
                    "--hide-scrollbars", "--force-device-scale-factor=1",
                    "--virtual-time-budget=3000",
                    "--screenshot=" + out_png,
                    "--window-size=%d,%d" % (size, size),
                    "file://" + os.path.abspath(html_path)],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def chamfer(mask, w, h, target):
    """3-4 chamfer 距离变换：返回每个像素到 target=1 区域的距离（单位: px*3）。"""
    INF = 1 << 20
    d = [0 if mask[i] == target else INF for i in range(w * h)]
    for y in range(h):
        row = y * w
        for x in range(w):
            i = row + x
            v = d[i]
            if v == 0:
                continue
            if x:
                v = min(v, d[i - 1] + 3)
            if y:
                v = min(v, d[i - w] + 3)
                if x:
                    v = min(v, d[i - w - 1] + 4)
                if x + 1 < w:
                    v = min(v, d[i - w + 1] + 4)
            d[i] = v
    for y in range(h - 1, -1, -1):
        row = y * w
        for x in range(w - 1, -1, -1):
            i = row + x
            v = d[i]
            if v == 0:
                continue
            if x + 1 < w:
                v = min(v, d[i + 1] + 3)
            if y + 1 < h:
                v = min(v, d[i + w] + 3)
                if x + 1 < w:
                    v = min(v, d[i + w + 1] + 4)
                if x:
                    v = min(v, d[i + w - 1] + 4)
            d[i] = v
    return d


def compare(pa, pb):
    wa, ha, ma = luminance_mask(pa)
    wb, hb, mb = luminance_mask(pb)
    if (wa, ha) != (wb, hb):
        raise SystemExit("两张图尺寸不一致: %s vs %s" % ((wa, ha), (wb, hb)))
    inter = sum(1 for i in range(wa * ha) if ma[i] and mb[i])
    union = sum(1 for i in range(wa * ha) if ma[i] or mb[i])
    ia = sum(ma)
    ib = sum(mb)
    iou = 100.0 * inter / union if union else 100.0
    # 轮廓像素 → 对方距离场
    da = chamfer(ma, wa, ha, 1)   # 到 A 墨迹的距离
    dbb = chamfer(mb, wa, ha, 1)  # 到 B 墨迹的距离
    haus = 0.0
    for y in range(ha):
        row = y * wa
        for x in range(wa):
            i = row + x
            if not ma[i]:
                continue
            if ((x and not ma[i - 1]) or (x + 1 < wa and not ma[i + 1])
                    or (y and not ma[i - wa]) or (y + 1 < ha and not ma[i + wa])):
                haus = max(haus, dbb[i] / 3.0)
            if not mb[i]:
                continue
            if ((x and not mb[i - 1]) or (x + 1 < wa and not mb[i + 1])
                    or (y and not mb[i - wb]) or (y + 1 < hb and not mb[i + wb])):
                haus = max(haus, da[i] / 3.0)
    return {"iou": iou, "area_a": ia, "area_b": ib, "hausdorff_px": haus,
            "size": [wa, ha]}


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) < 2:
        print(__doc__)
        sys.exit(1)
    a_path, b_path = args[0], args[1]
    size = 780
    for a in sys.argv[1:]:
        if a.startswith("--size="):
            size = int(a.split("=")[1])
    page_out = None
    for a in sys.argv[1:]:
        if a.startswith("--page="):
            page_out = a.split("=", 1)[1]
        elif a == "--page":
            page_out = os.path.splitext(b_path)[0] + "-对比.html"

    chrome = find_chrome()
    if not chrome:
        print("✗ 找不到 Chrome/Chromium，无法渲染。可改用肉眼核对或安装 Chrome。")
        sys.exit(2)

    vb = svg_viewbox(a_path)
    tmp = tempfile.mkdtemp(prefix="iconverify-")
    h_a = os.path.join(tmp, "a.html")
    h_b = os.path.join(tmp, "b.html")
    p_a = os.path.join(tmp, "a.png")
    p_b = os.path.join(tmp, "b.png")
    open(h_a, "w").write(shell(vb, embed(a_path, vb), size=size))
    open(h_b, "w").write(shell(vb, embed(b_path, vb), size=size))
    render(chrome, h_a, p_a, size, tmp)
    render(chrome, h_b, p_b, size, tmp)

    r = compare(p_a, p_b)
    px_per_unit = size / (vb[2] + 2)
    haus_u = r["hausdorff_px"] / px_per_unit
    iou = r["iou"]
    darea = 100.0 * (r["area_b"] - r["area_a"]) / max(1, r["area_a"])

    print("渲染: %dx%d  (%g px/单位)" % (r["size"][0], r["size"][1], px_per_unit))
    print("IoU          %6.2f %%      (阈值 ≥ 99.0)" % iou)
    print("轮廓偏离 max %6.3f 单位   (阈值 ≤ 0.08)" % haus_u)
    print("面积差       %+6.2f %%" % darea)
    ok = iou >= 99.0 and haus_u <= 0.08
    print("结论: %s" % ("✓ 通过" if ok else "✗ 未通过 —— 回到 analyze.py 复核线宽/端点/圆心"))

    if page_out:
        if page_out.endswith(".png"):
            html = page_out[:-4] + ".html"
        else:
            html = page_out
        open(html, "w").write(page_html(vb, a_path, b_path, 300))
        png = os.path.splitext(html)[0] + ".png"
        subprocess.run([chrome, "--headless=new", "--no-sandbox", "--disable-gpu",
                        "--hide-scrollbars", "--force-device-scale-factor=2",
                        "--virtual-time-budget=3000", "--screenshot=" + png,
                        "--window-size=640,%d" % (300 + 40),
                        "file://" + os.path.abspath(html)],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("对比页: %s\n对比图: %s" % (html, png))
    shutil.rmtree(tmp, ignore_errors=True)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
