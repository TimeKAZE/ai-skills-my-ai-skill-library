"""极简 PNG 解码（纯标准库），供 verify.py 做像素比对。

只支持 8bit RGB/RGBA、非隔行——即 Chrome/headless 截图的标准输出。
"""

import struct
import zlib


def read_png(path):
    """返回 (w, h, nch, data)。data 为 bytes，逐像素 RGB(A) 排列。"""
    raw_file = open(path, "rb").read()
    if raw_file[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("不是 PNG: %s" % path)
    pos = 8
    idat = b""
    w = h = ct = None
    while pos < len(raw_file):
        ln, typ = struct.unpack(">I4s", raw_file[pos:pos + 8])
        pos += 8
        chunk = raw_file[pos:pos + ln]
        pos += ln + 4
        if typ == b"IHDR":
            w, h, bd, ct, _comp, _filt, inter = struct.unpack(">IIBBBBB", chunk)
            if bd != 8 or ct not in (2, 6) or inter != 0:
                raise ValueError("仅支持 8bit RGB/RGBA 非隔行 PNG (bd=%d ct=%d inter=%d)"
                                 % (bd, ct, inter))
        elif typ == b"IDAT":
            idat += chunk
        elif typ == b"IEND":
            break
    raw = zlib.decompress(idat)
    nch = 3 if ct == 2 else 4
    stride = w * nch
    out = bytearray(h * stride)
    prev = bytearray(stride)
    p = 0
    for y in range(h):
        f = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if f == 1:
            for i in range(nch, stride):
                line[i] = (line[i] + line[i - nch]) & 255
        elif f == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif f == 3:
            for i in range(stride):
                a = line[i - nch] if i >= nch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 255
        elif f == 4:
            for i in range(stride):
                a = line[i - nch] if i >= nch else 0
                b = prev[i]
                c = prev[i - nch] if i >= nch else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 255
        out[y * stride:(y + 1) * stride] = line
        prev = line
    return w, h, nch, bytes(out)


def luminance_mask(path, w=None):
    """转成 0/1 墨迹蒙版。阈值取「背景(255) 与 最暗墨色」的中点，抗锯齿像素按 50% 覆盖切分。"""
    w_, h, nch, data = read_png(path)
    lum = bytearray(w_ * h)
    lmin = 255
    for i in range(w_ * h):
        o = i * nch
        v = (data[o] * 299 + data[o + 1] * 587 + data[o + 2] * 114) // 1000
        lum[i] = v
        if v < lmin:
            lmin = v
    thr = (255 + lmin) // 2
    mask = bytearray(1 if v < thr else 0 for v in lum)
    return w_, h, mask
