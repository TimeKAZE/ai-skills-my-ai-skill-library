"""逆向分析：把 fill 闭合轮廓的 SVG 拆成「圆点 / 圆环 / 折线轮廓」并给出 stroke 版建议。

用法:
    python3 analyze.py icon.svg
    python3 analyze.py icon.svg --json

输出为人类可读报告（默认）或 JSON（--json，便于批量处理）。
不修改任何文件；只做测量与建议。
"""

import json
import math
import re
import sys
import xml.etree.ElementTree as ET

from svgpath import (angle_of, bbox, fit_circle, fit_ring, flatten, parse_path,
                     poly, straight_runs)


def load_svg(path):
    """返回 (viewBox, [(d, id, has_transform)])。"""
    try:
        root = ET.parse(path).getroot()
    except Exception:
        txt = open(path, encoding="utf-8", errors="ignore").read()
        vb = re.search(r'viewBox\s*=\s*"([^"]+)"', txt)
        ds = re.findall(r'<path[^>]*\sd\s*=\s*"([^"]+)"', txt)
        return (vb.group(1) if vb else "0 0 24 24"), [(d, "", False) for d in ds]
    tag = lambda e: e.tag.split("}")[-1]
    vb = root.get("viewBox")
    items = []

    def num_of(el, k, d=0.0):
        try:
            return float(el.get(k, d))
        except (TypeError, ValueError):
            return d

    def walk(node, tf):
        for ch in node:
            t = tag(ch)
            has = tf or bool(ch.get("transform"))
            if t == "path" and ch.get("d"):
                items.append((ch.get("d"), ch.get("id", ""), has))
            elif t == "circle":
                cx, cy, r = num_of(ch, "cx"), num_of(ch, "cy"), num_of(ch, "r")
                if r > 0:
                    items.append(("M%g %ga%g %g 0 1 0 %g 0a%g %g 0 1 0 %g 0" % (
                        cx - r, cy, r, r, 2 * r, r, r, -2 * r), ch.get("id", ""), has))
            elif t == "rect":
                x, y = num_of(ch, "x"), num_of(ch, "y")
                w, h = num_of(ch, "width"), num_of(ch, "height")
                if w > 0 and h > 0:
                    items.append(("M%g %gH%gV%gH%gZ" % (x, y, x + w, y + h, x),
                                  ch.get("id", ""), has))
            elif t in ("g", "svg", "symbol", "defs"):
                walk(ch, has)
    walk(root, False)
    return vb or "0 0 24 24", items


def dedupe_vertices(pts, vidx):
    out = []
    for k in vidx:
        p = pts[k]
        if not out or math.dist(p, out[-1][1]) > 1e-9:
            out.append((k, p))
    if len(out) > 1 and math.dist(out[0][1], out[-1][1]) < 1e-9:
        out.pop()
    return out


def find_caps(pts, verts, w, tol=0.12):
    """找出「一对边缘端点相距≈线宽、中间由半圆（或直线切口）连接」的位置 = 端头。

    返回 [{p1, p2, center, kind, width, roundness}]，kind ∈ {round, butt}。
    center 就是 stroke 中线的端点——这是逆向时最关键的坐标。
    """
    caps = []
    n = len(verts)
    if w <= 0 or n < 3:
        return caps
    # 累积弧长，用来 O(1) 判断两个顶点之间「沿路径」的哪一侧更短（不能用点数判断！）
    cum = [0.0]
    for k in range(1, len(pts)):
        cum.append(cum[-1] + math.dist(pts[k - 1], pts[k]))
    total = cum[-1]

    def seg_len(a, b):
        return cum[b] - cum[a] if a <= b else (total - cum[a]) + cum[b]

    def seg_pts(a, b):
        return pts[a:b + 1] if a <= b else pts[a:] + pts[:b + 1]

    for i in range(n):
        for j in range(i + 1, n + 1):
            p1 = verts[i % n][1]
            p2 = verts[j % n][1]
            d = math.dist(p1, p2)
            if abs(d - w) > tol * w:
                continue
            i1, i2 = verts[i % n][0], verts[j % n][0]
            alen = seg_len(i1, i2)
            if alen <= seg_len(i2, i1):
                seg = seg_pts(i1, i2)
            else:
                alen = seg_len(i2, i1)
                seg = seg_pts(i2, i1)
            if len(seg) < 3:
                # 两点之间就是一段直线 → 平头切口
                caps.append({"p1": p1, "p2": p2,
                             "center": ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2),
                             "kind": "butt", "roundness": 0.0,
                             "radius": d / 2, "width": d})
                continue
            mid = ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2)
            ds = [math.dist(p, mid) for p in seg[1:-1]] or [math.dist(seg[0], mid)]
            bulge, dmin = max(ds), min(ds)
            # 判圆头要拟合这段连接线的曲率半径：半圆头必然是「圆心=中点、半径=w/2」。
            # 只看 bulge 会把「同一条边上相距 w 的两个点」误判成圆头（切向弦也是凸的）。
            ccx, ccy, cr, _ = fit_circle(seg)
            roundness = (dmin / bulge) if bulge > 1e-9 else 0.0
            is_cap = (abs(cr - w / 2) < 0.15 * w
                      and math.dist((ccx, ccy), mid) < 0.25 * w)
            straight = abs(alen - d) < 0.03 * d      # 两点之间是一条直线段 = 平头切口
            if is_cap:
                kind = "round"
            elif straight:
                kind = "butt"
            else:
                continue   # 只是凑巧相距一个线宽，不是端头（如环的内外边缘、拐角对角点）
            caps.append({"p1": p1, "p2": p2, "center": mid, "kind": kind,
                         "roundness": roundness, "radius": bulge, "width": d})
    uniq = []
    for c in caps:
        if not any(math.dist(c["center"], u["center"]) < 0.25 * w for u in uniq):
            uniq.append(c)
    return uniq


def parallel_hint(runs):
    """平行长直边的间距（最小的几个）→ 用来估线宽。"""
    out = []
    for a in range(len(runs)):
        for b in range(a + 1, len(runs)):
            (p0, p1, L1), (p2, p3, L2) = runs[a], runs[b]
            u = (p1[0] - p0[0], p1[1] - p0[1])
            v = (p3[0] - p2[0], p3[1] - p2[1])
            nu, nv = math.hypot(*u), math.hypot(*v)
            if nu < 1e-9 or nv < 1e-9:
                continue
            cross = abs(u[0] * v[1] - u[1] * v[0]) / (nu * nv)
            if cross > 0.02:
                continue
            # 点到直线距离
            d = abs(u[0] * (p2[1] - p0[1]) - u[1] * (p2[0] - p0[0])) / nu
            if d < 1e-6:
                continue
            # 投影是否重叠（同一段"边"的两侧）
            t = ((p2[0] - p0[0]) * u[0] + (p2[1] - p0[1]) * u[1]) / (nu * nu)
            if -0.2 < t < 1.2:
                out.append(d)
    return sorted(out)


def ring_score(pts, c0, r_in, r_out, w, bins=72):
    """环度：同一角度扇区里是否同时存在「内圆点」和「外圆点」。

    真圆环在弧段覆盖的每个角度上都会同时打到内、外两条边；胶囊/圆角矩形这类
    形状做不到，所以这个指标能把「拟合残差小但不是环」的情况筛掉。
    """
    occ = {}
    for p in pts:
        rr = math.hypot(p[0] - c0[0], p[1] - c0[1])
        b = int((angle_of(c0, p) % 360) // (360.0 / bins))
        near_in = abs(rr - r_in) < 0.35 * w
        near_out = abs(rr - r_out) < 0.35 * w
        v = occ.setdefault(b, [False, False])
        v[0] = v[0] or near_in
        v[1] = v[1] or near_out
    if not occ:
        return 0.0
    both = sum(1 for v in occ.values() if v[0] and v[1])
    return both / float(len(occ))


def analyze_sub(sp, canvas, origin=(0.0, 0.0)):
    pts, vidx = flatten(sp)
    if len(pts) < 4:
        return None
    x0, y0, x1, y1 = bbox(pts)
    verts = dedupe_vertices(pts, vidx)
    info = {
        "segs": len(sp.segs), "closed": sp.closed,
        "bbox": [round(v, 4) for v in (x0, y0, x1, y1)],
        "size": [round(x1 - x0, 4), round(y1 - y0, 4)],
    }
    cx, cy, r, rms = fit_circle(pts)
    scale = max(canvas)
    # 1) 圆点 / 实心圆
    if r > 0 and rms < 0.02 * r and 2 * r < 0.55 * scale:
        info.update({"type": "dot", "center": [round(cx, 4), round(cy, 4)],
                     "diameter": round(2 * r, 4), "rms": round(rms, 5)})
        info["suggest"] = 'M%g %gh.01' % (round(cx, 4), round(cy, 4))
        info["suggest_attrs"] = {'stroke-width': round(2 * r, 4), 'stroke-linecap': 'round'}
        return info
    # 1b) 大圆 = 实心圆，不是描边产物
    if r > 0 and rms < 0.02 * r:
        info.update({"type": "solid", "center": [round(cx, 4), round(cy, 4)],
                     "diameter": round(2 * r, 4),
                     "warning": "半径 %.3f 的实心圆，不是 outline stroke 的产物" % r})
        return info
    # 2) 圆环
    ring = fit_ring(pts)
    if ring and ring["w"] > 0.03 * scale and ring["rms"] < 0.04 * ring["r_out"] \
            and ring_score(pts, (ring["cx"], ring["cy"]), ring["r_in"], ring["r_out"],
                           ring["w"]) > 0.6:
        # 对齐到设计栅格：图标几乎都画在画布中心，坐标落在 0.01 精度上。
        # 拟合圆心常被贝塞尔近似的内缘带偏 0.01~0.02，吸附后像素重合度更高。
        ccx, ccy = origin[0] + canvas[0] / 2, origin[1] + canvas[1] / 2
        c0 = [ring["cx"], ring["cy"]]
        if abs(c0[0] - ccx) < 0.05:
            c0[0] = ccx
        if abs(c0[1] - ccy) < 0.05:
            c0[1] = ccy
        c0 = tuple(c0)
        caps = find_caps(pts, verts, ring["w"])
        rnd = [c for c in caps if c["kind"] == "round"]
        angs = [angle_of(c0, p) % 360 for p in pts]

        # 线宽优先用「端点圆弧两个边缘端点的间距」——那是直接的 stroke 宽度，
        # 比环形拟合稳（原稿内缘常是贝塞尔近似圆，半径有 ±0.05 抖动）
        w = ring["w"]
        r_out = ring["r_out"]
        if len(rnd) == 2:
            w = sum(c["width"] for c in rnd) / 2
        w = round(w, 2)
        if abs(r_out - round(r_out, 2)) < 0.02:
            r_out = round(r_out, 2)
        R = r_out - w / 2

        if len(rnd) == 2:
            # 两个端点圆弧的中心 = 中线弧的两个端点；方向由「弧中点附近有没有点」判定
            pa, pb = rnd[0]["center"], rnd[1]["center"]
            a0, a1 = angle_of(c0, pa), angle_of(c0, pb)

            def mid_points(a_from, a_to, tol=6.0):
                sw = (a_to - a_from) % 360
                m = (a_from + sw / 2) % 360
                cnt = sum(1 for a in angs if min(abs(a - m) % 360, 360 - abs(a - m) % 360) < tol)
                return sw, cnt
            s01, n01 = mid_points(a0, a1)
            s10, n10 = mid_points(a1, a0)
            if n01 >= n10:
                sweep = s01
            else:
                pa, pb = pb, pa
                sweep = s10
            # 端点投影到中线圆上：端点圆弧的中心与拟合 R 会差 0.01~0.02，
            # 直接拿来当弧端点会让弧略微偏离圆，投影后既保留角度又严格落在圆上
            def on_circle(q):
                dx, dy = q[0] - c0[0], q[1] - c0[1]
                L = math.hypot(dx, dy) or 1.0
                return (c0[0] + dx / L * R, c0[1] + dy / L * R)
            pa, pb = on_circle(pa), on_circle(pb)
            gap = 360 - sweep
            cap_style = "round"
        else:
            cap_style = "butt"
            # 无圆头：用「贴着外圆」的点求角度范围（端点圆弧会污染角度）
            rs_all = [math.hypot(p[0] - c0[0], p[1] - c0[1]) for p in pts]
            edge = [a for a, rr in zip(angs, rs_all) if abs(rr - r_out) < 0.06 * w]
            if len(edge) < 20:
                edge = [a for a, rr in zip(angs, rs_all)
                        if min(abs(rr - ring["r_in"]), abs(rr - r_out)) < 0.08 * w]
            edge = sorted(edge or angs)
            best = (0, edge[0], edge[0])
            for k in range(len(edge)):
                a1_ = edge[k]
                a2_ = edge[(k + 1) % len(edge)] + (360 if k == len(edge) - 1 else 0)
                if a2_ - a1_ > best[0]:
                    best = (a2_ - a1_, a1_, a2_ % 360)
            gap, g_start, g_end = best
            sweep = 360 - gap
            pa = poly(c0, R, g_end)
            pb = poly(c0, R, g_start)

        info.update({
            "type": "ring",
            "center": [round(c0[0], 4), round(c0[1], 4)],
            "r": round(R, 4), "w": round(w, 4),
            "r_in": round(r_out - w, 4), "r_out": round(r_out, 4),
            "gap_deg": round(gap, 2), "arc_deg": round(sweep, 2),
            "cap_style": cap_style,
            "caps": [{"p": [round(c["center"][0], 4), round(c["center"][1], 4)],
                      "angle": round(angle_of(c0, c["center"]), 2),
                      "width": round(c["width"], 4), "kind": c["kind"]} for c in caps],
        })
        info["suggest"] = "M%.4f %.4fA%g %g 0 %d 0 %.4f %.4f" % (
            pa[0], pa[1], round(R, 4), round(R, 4), 1 if sweep > 180 else 0, pb[0], pb[1])
        info["suggest_attrs"] = {"stroke-width": round(w, 4), "stroke-linecap": cap_style}
        return info

    # 3) 折线 / 自由轮廓
    runs = straight_runs(sp)
    caps = find_caps(pts, verts, 0.0) or []
    dists = parallel_hint([r for r in runs if r[2] > 0.05 * scale])
    info.update({
        "type": "outline",
        "straight_runs": [[round(v, 4) for v in r[0]] + [round(v, 4) for v in r[1]] + [round(r[2], 4)]
                          for r in runs if r[2] > 0.05 * scale],
        "parallel_dists": [round(d, 4) for d in dists[:8]],
        "vertices": [[round(p[0], 4), round(p[1], 4)] for _, p in verts],
    })
    w_guess = dists[0] if dists else None
    if not w_guess and not caps:
        info["warning"] = "既没有平行长边也没有端头，疑似实心图形/插画，可能无法还原"
    if w_guess:
        caps = find_caps(pts, verts, w_guess)
        info["w_guess"] = round(w_guess, 4)
        info["caps"] = [{"p": [round(c["center"][0], 4), round(c["center"][1], 4)],
                         "kind": c["kind"]} for c in caps]
    return info


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    path = sys.argv[1]
    as_json = "--json" in sys.argv
    vb, items = load_svg(path)
    parts = [float(v) for v in re.split(r"[,\s]+", vb.strip()) if v]
    canvas = (parts[2], parts[3]) if len(parts) == 4 else (24, 24)
    report = {"file": path, "viewBox": vb, "canvas": canvas, "paths": []}
    for d, eid, tf in items:
        subs = parse_path(d)
        entry = {"id": eid, "transform": tf, "subpaths": []}
        for sp in subs:
            info = analyze_sub(sp, canvas, (parts[0], parts[1]) if len(parts) == 4 else (0.0, 0.0))
            if info:
                entry["subpaths"].append(info)
        report["paths"].append(entry)

    if as_json:
        print(json.dumps(report, ensure_ascii=False, indent=1))
        return

    print("文件: %s" % path)
    print("画布: %g × %g    viewBox: %s" % (canvas[0], canvas[1], vb))
    total = sum(len(p["subpaths"]) for p in report["paths"])
    print("path 数: %d    子路径数: %d" % (len(report["paths"]), total))
    try:
        txt = open(path, encoding="utf-8", errors="ignore").read()
        if 'fill="none"' in txt and "stroke=" in txt and 'fill="#' not in txt:
            print("提示: 这个文件本身就是 stroke 描边（fill=\"none\" + stroke），不需要逆向，"
                  "直接改 stroke-width / linecap 即可")
    except OSError:
        pass
    if any(not p["subpaths"] for p in report["paths"]):
        print("提示: 有 path 未分类（顶点过少），可能它本来就是一条描边线，而非 outline stroke 轮廓")
    if any(p["transform"] for p in report["paths"]):
        print("⚠ 存在 transform 属性：坐标不是最终坐标，先统一展开变换（Inkscape/Illustrator 里 Object→Flatten 或手动 bake）")
    n = 0
    widths = []
    for p in report["paths"]:
        for s in p["subpaths"]:
            n += 1
            if s["type"] == "dot":
                print("\n[%d] 圆点        中心 (%.4f, %.4f)   直径 %.4f   (圆度 rms %.5f)"
                      % (n, s["center"][0], s["center"][1], s["diameter"], s["rms"]))
                print("    → <path d=\"%s\" stroke-width=\"%g\" stroke-linecap=\"round\"/>"
                      % (s["suggest"], s["diameter"]))
            elif s["type"] == "ring":
                widths.append(s["w"])
                print("\n[%d] 圆环        圆心 (%.4f, %.4f)   中线 R %.4f   线宽 %.4f  (内 %.4f / 外 %.4f)"
                      % (n, s["center"][0], s["center"][1], s["r"], s["w"], s["r_in"], s["r_out"]))
                print("    缺口 %.2f°   实弧 %.2f°   端点: %s"
                      % (s["gap_deg"], s["arc_deg"], s["cap_style"]))
                for c in s["caps"]:
                    print("      · %-5s (%8.4f, %8.4f)  @ %7.2f°"
                          % (c["kind"], c["p"][0], c["p"][1], c["angle"]))
                print("    → <path d=\"%s\" stroke-width=\"%g\" stroke-linecap=\"%s\"/>"
                      % (s["suggest"], s["w"], s["cap_style"]))
            elif s["type"] == "solid":
                print("\n[%d] 实心图形    中心 (%.4f, %.4f)   直径 %.4f" % (n, s["center"][0], s["center"][1], s["diameter"]))
                print("    ⚠ %s → 直接告诉用户这个图标不是描边图形，无法还原为 stroke" % s["warning"])
            else:
                print("\n[%d] 折线轮廓    bbox %.3f,%.3f → %.3f,%.3f   长直边 %d 条"
                      % (n, s["bbox"][0], s["bbox"][1], s["bbox"][2], s["bbox"][3],
                         len(s["straight_runs"])))
                if s.get("w_guess"):
                    widths.append(s["w_guess"])
                    print("    疑似线宽 %.4f" % s["w_guess"])
                    for c in s.get("caps", []):
                        print("      · %s (%8.4f, %8.4f)" % (c["kind"], c["p"][0], c["p"][1]))
                if s.get("parallel_dists"):
                    print("    平行边间距: %s" % ", ".join("%.3f" % d for d in s["parallel_dists"]))
                for r in s["straight_runs"]:
                    print("      边 (%8.4f,%8.4f) → (%8.4f,%8.4f)  L=%.3f"
                          % (r[0], r[1], r[2], r[3], r[4]))
                print("    全部顶点: %s" % ", ".join("(%.3f,%.3f)" % (v[0], v[1]) for v in s["vertices"][:24]))
                print("    → 取每对平行长边的中线得到中心线，端头用上表 cap，拐点用 round join")
                if s.get("warning"):
                    print("    ⚠ %s" % s["warning"])
    if widths:
        # 1.5% 容差聚类（不同部位量出来会差 0.001~0.01，属同一档）
        clusters = []
        for w in sorted(widths):
            if clusters and abs(w - clusters[-1][0]) <= 0.015 * clusters[-1][0]:
                clusters[-1].append(w)
            else:
                clusters.append([w])
        clusters.sort(key=len, reverse=True)
        best = clusters[0]
        med = best[len(best) // 2]
        print("\n提示: 出现最多的线宽 ≈ %.3f（%d 处，共 %d 档）；整套 icon 建议统一到它"
              % (med, len(best), len(clusters)))


if __name__ == "__main__":
    main()
