#!/bin/bash
# Style Texture · one-click build for texture/
# Double-click this file on macOS (requires Node.js, one-time install)
# Style Texture · 一键打包 texture/ 里的贴图（Mac 上双击运行）

cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"

echo "==========================================="
echo "  Style Texture · Build custom textures"
echo "  Style Texture · 打包自定义贴图"
echo "==========================================="
echo

if ! command -v node >/dev/null 2>&1; then
  echo "❌ Node.js not found / 没有找到 Node.js"
  echo
  echo "Building needs Node.js (free). Install it once:"
  echo "  1. Open  https://nodejs.org/"
  echo "  2. Download the LTS build and install it (keep clicking Next)"
  echo "  3. Double-click this file again"
  echo
  echo "这个打包步骤需要 Node.js（免费软件），安装一次以后都能用："
  echo "  1. 浏览器打开  https://nodejs.org/"
  echo "  2. 下载 LTS 版本，双击安装（全部下一步即可）"
  echo "  3. 装好后重新双击本文件"
  echo
  echo "macOS 提示「无法打开，因为无法验证开发者」时："
  echo "  Right-click this file → Open → click Open again in the dialog"
  echo
  read -n 1 -s -r -p "Press any key to close / 按任意键关闭窗口…"
  exit 1
fi

node build-textures.js
status=$?

echo
if [ $status -eq 0 ]; then
  echo "✅ Build finished. / 打包完成。"
  echo "Back in Figma: close the plugin, then reopen Plugins → Development → Style Texture."
  echo "回到 Figma：关掉插件面板，再打开 Plugins → Development → Style Texture，"
  echo "新的贴图会出现在 Textures / 纹理预设 里。"
else
  echo "❌ Build failed. / 打包失败。"
  echo "Please screenshot the messages above. / 请把上面的提示截图发给我。"
fi

echo
read -n 1 -s -r -p "Press any key to close / 按任意键关闭窗口…"
