# Style Texture

**English** · [简体中文](README.zh-CN.md)

A Figma plugin that overlays a tileable texture on selected **Frames / Components**, similar to Photoshop's *Pattern Overlay* layer style.
It ships **15** seamless built-in textures (Dots, Diagonal, Grid, X-hatch, Vertical, Horiz., Checker, Dot grid, Big dots, Dense, Dashes, V. dashes, Crosses, Zigzag, Big grid) and supports two ways to add your own:
use **+ Import** in the panel (works with any distribution), or drop images into `texture/` and run the build script (source installs only).
Color, pattern size, opacity and blend mode update live. A **中 / EN** switch in the top-right corner translates the UI and the 15 built-in texture names;
the names of local and imported textures stay exactly as they are (the file name is the display name), so Chinese and English users can share the same setup.

## Install (local development)

1. Open the **Figma desktop app**
2. **Plugins → Development → Import plugin from manifest…**
3. Choose `manifest.json` in this folder
4. Launch it via **Plugins → Development → Style Texture**

Want to preview the UI in a browser first? Serve the folder and open `preview.html` (mock data, not part of the plugin).

```bash
python3 -m http.server 8899
# open http://localhost:8899/preview.html
```

## Usage

1. Select one or more **Frames / Components** on the canvas
2. Pick a texture (or **+ Import** your own image), then adjust color, pattern size, opacity and blend mode
3. Click **Apply texture**
4. Applying again to the same Frame updates the existing layer instead of stacking new ones; **Remove** clears the texture

The result is a rectangle named `Style Texture · Dots` (or `Style Texture · 网点` when the panel is in Chinese) placed on top of the Frame:

- Same size as the Frame, stretching with it (`STRETCH` constraints)
- Inside auto-layout Frames it is set to absolute positioning and does not affect layout
- Rounded corners are copied from the Frame
- The last used settings are remembered and restored next time

## Importing textures (works in the Community build)

**+ Import** at the right of the Textures section accepts multiple `.svg` / `.png` / `.jpg` / `.webp` files at once. You can also drag images into the plugin window or press <kbd>⌘V</kbd> to paste:

- Images must be square and seamless; non-square files are reported and skipped
- `.svg` and images with alpha are tinted by default; others keep their original colors — toggle with "Tint with chosen color"
- Large images are resampled automatically (long edge ≤1024px, WebP/PNG); keep the source under 8 MB
- Imported textures appear below the gray divider in the library area (the area scrolls on its own when there are many); use the × on a card to delete it
- Data lives in `figma.clientStorage` (per user). Limits: ~1.5 MB per texture, up to 24 textures, ~4.5 MB total
- If you exceed the limits you will be asked to clean up; the current session still works, but nothing is persisted

This path does not depend on the plugin folder, so it **also works after publishing to Figma Community**.

> **About persistence**: `clientStorage` requires the plugin to have an ID. A local development build
> whose `manifest.json` has no `id` will report `Cannot access client storage without a plugin ID` —
> imports and textures keep working for the current session but are lost when the plugin closes.
> You don't have to publish to the Community to fix this: in Figma, use
> **Plugins → Development → New plugin…**, put the generated `id` into this project's
> `manifest.json`, and import it again. Publishing to the Community (or creating a private plugin) also assigns an ID.

## Custom texture library (`texture/`, source installs only)

> Figma plugins cannot read their own folder at runtime, and Community installs have no plugin folder at all.
> This section only applies to source installs from GitHub via `Import plugin from manifest…`;
> for the Community build, use **+ Import** above.

Drop images into **`texture/`**, run the build once, and they become preset cards.

### One-click build (no terminal)

| OS | Double-click |
| --- | --- |
| macOS | `build-textures.command` |
| Windows | `build-textures.bat` |

The first run needs [Node.js](https://nodejs.org/) (LTS build, keep clicking Next); the script checks for it and tells you if it's missing. On macOS, if you see "cannot verify the developer", **right-click the file → Open**.

After the build, return to Figma: close the plugin panel and relaunch **Plugins → Development → Style Texture**.

### Or use the terminal

```bash
# 1. put .svg / .png / .jpg files into texture/
# 2. build them into the plugin
node build-textures.js
# 3. reload the plugin in Figma
```

- The file name becomes the display name, e.g. `stripe-bold.png` → "stripe-bold"
- Files must be square; unequal dimensions or unreadable sizes are skipped with a message in the terminal
- Textures must tile seamlessly: the whole image repeats, so edges have to connect (see `texture/dot.svg`)
- `.svg` and `.png` with alpha are tinted with the panel color by default; `.jpg` keeps its original colors and the "Tint with chosen color" switch appears in the panel

> Why a build step: Figma plugins **cannot read their own folder** at runtime. The UI only gets `ui.html`, so relative image paths fail.
> The script inlines images as data URLs into `<script id="texture-library">` in `ui.html` and writes the preset list into
> `IMAGE_PRESETS` in `code.js`. Both blocks are generated automatically — don't edit them by hand.

## Presets drawn in code

Besides images, you can compose presets from primitives in the **`TEXTURE_PRESETS` array at the top of `code.js`** —
ideal for wireframes, dots and other vector patterns (they stay crisp at any size).

```js
const TEXTURE_PRESETS = [
  // ...the 15 built-in presets (Dots / Diagonal / … / Big grid)

  // Example: short dashes
  {
    id: 'dashes',            // unique English id
    name: '短横线',          // display name (Chinese UI)
    nameEn: 'Dashes',        // display name (English UI; omit to reuse `name`)
    tile: 24,                // pattern cell size (logical px)
    shapes: [
      // 12px on / 12px off, offset by half a cell on the second row
      { type: 'rect', x: 0, y: 6, w: 12, h: 1 },
      { type: 'rect', x: 12, y: 18, w: 12, h: 1 },
    ],
  },
];
```

A cell (tile coordinates, origin at the top-left) can contain three kinds of shapes:

```js
{ type: 'circle', x: 0, y: 0, r: 3 }                         // filled circle
{ type: 'rect',   x: 4, y: 4, w: 8, h: 4 }                    // filled rectangle
{ type: 'line',   x1: 0, y1: 0, x2: 16, y2: 0, width: 1 }     // line, optional cap: 'round'
```

Each shape can override the color with `color: '#ff0000'`; otherwise the color picked in the panel is used.

### How seamless tiling works

The plugin draws every shape 9 times (`-tile / 0 / +tile` offset combinations) and wraps anything crossing an edge to the opposite side. So:

- Shapes fully inside the cell → seamless by construction
- Shapes crossing an edge (diagonals, edge-hugging grid lines) → reconnected by the wrapped copies
- A circle at a corner → four quarter circles join into one full dot

## File structure

```
manifest.json            plugin manifest (no network access)
code.js                  main thread: presets, selection handling, create/update the texture layer
ui.html                  plugin UI: preset cards, tile generation, live preview, controls
build-textures.js        bundles images from texture/ into the plugin (node build-textures.js)
build-textures.command   one-click build (double-click on macOS)
build-textures.bat       one-click build (double-click on Windows)
texture/                 custom texture sources (svg / png / jpg) + usage notes
preview.html             browser mock preview of the UI (not part of the plugin)
intro.html               standalone intro / landing page (open in a browser)
intro-en.png / intro-zh.png  plugin panel screenshots used by intro.html
README.md / README.zh-CN.md  English / Chinese docs
```

## Implementation notes

- Textures are generated in the UI canvas at 2x resolution as transparent PNGs, then applied as an `IMAGE` fill with `scaleMode: 'TILE'` and `scalingFactor: 0.5`, so they stay crisp and seamless at the logical size
- Custom textures are scaled onto a 2x canvas the same way; tinting uses `source-in` compositing, replacing only opaque pixels while preserving anti-aliased edges
- The overlay layer is tagged with `pluginData`, so re-applying updates it in place instead of stacking layers
- Settings (including each texture's tint toggle) are stored in `figma.clientStorage` after every apply and restored on the next launch
- The panel language (中 / EN) is saved with the settings; English preset names live in the `nameEn` field, while local and imported texture names are never translated
- Only `FRAME` / `COMPONENT` are processed; other layers are counted as "ignored" in the footer

## Known limitations

- Only Frames and components are supported (plain shapes, text and groups are not)
- Textures are bitmaps: if you place a Frame on a very large canvas or export at high scale, increase "Pattern size" for sharper edges
- "Pattern size" also scales line weight and dot radius (same as Photoshop's pattern scaling)
- Changing "Pattern size" creates a new texture asset; identical settings reuse the cache, but trying many sizes adds image assets to the file
- After adding images to `texture/`, you must re-run `node build-textures.js` for new cards to appear
- `texture/` only works for source installs; Community builds should use **+ Import**, subject to `clientStorage` limits (~1.5 MB per texture / up to 24 / ~4.5 MB total; oversized images are resampled)
