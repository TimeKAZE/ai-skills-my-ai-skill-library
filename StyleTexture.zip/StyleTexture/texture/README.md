# texture/ —— 自定义贴图库 / Custom texture library

**English** · [简体中文](#简体中文)

Drop textures into this folder, run `node build-textures.js` once, and they show up in the plugin's preset panel.

> **Local source build only.** The Figma plugin runtime cannot read its own folder, and Community builds have no plugin directory at all.
> If the plugin is published to Figma Community, tell users to pick images with **＋ Import texture** in the panel instead.

## Usage

1. Put texture files into `texture/` (`.svg` `.png` `.jpg` `.jpeg` are supported).
2. Build: go back to the plugin root and double-click `build-textures.command` (macOS) or `build-textures.bat` (Windows).
   If you prefer a terminal, run this from the root instead:
   ```bash
   node build-textures.js
   ```
3. Re-run the plugin in Figma (or use **Reload plugin** in the plugin menu).

The file name becomes the name shown in the panel — `stripe-coarse.png` shows up as `stripe-coarse`.

## Texture requirements

- **Must be square**: images with unequal width and height are skipped with a terminal warning (the script cannot crop them safely).
- **Must tile seamlessly**: the texture repeats as a whole block, so the pattern has to connect across edges.
  Shapes cut off by the edge of an SVG / PNG are not mirrored automatically when tiled — handle the cross-edge shapes in the source file
  (see `dot.svg` in this folder: the corner dots are clipped, and tiling completes them).
- SVG textures should declare `width` / `height` on `<svg>`, or at least a `viewBox`.
- Keep sizes reasonable: texture size directly sets the default tiling density; 48–256px works well.

## Tint rules

- `.svg` and `.png` with an alpha channel → tinted with the selected color by default.
- `.jpg` / `.png` without transparency → original colors kept by default; a **Tint** toggle appears in the panel.

Turn tint off and the color picker greys out; the texture is tiled in its own colors.

## Why the build script exists

The Figma plugin runtime **cannot read the plugin's own folder**: `main` only gets `code.js`,
and the UI only gets the single entry file `ui.html`; relative image and script paths do not load.
So the script inlines images as data URLs into `ui.html` (`<script id="texture-library">`)
and writes the preset list into `code.js` (`IMAGE_PRESETS`). Both blocks are generated — do not edit them by hand.

## 简体中文

把贴图丢进这个文件夹，运行一次 `node build-textures.js`，它们就会出现在插件的预设面板里。

> **只对本地源码版有效。** Figma 插件运行时读不到自己的文件夹，Community 安装的版本也没有插件目录；
> 如果插件是发布到 Figma Community 的，请让用户用面板里的「＋ 导入贴图」选图。

### 用法

1. 把贴图文件放进 `texture/`（支持 `.svg` `.png` `.jpg` `.jpeg`）
2. 打包：回到插件根目录，双击 `build-textures.command`（macOS）或 `build-textures.bat`（Windows）；
   习惯终端的话也可以在根目录运行：
   ```bash
   node build-textures.js
   ```
3. 回 Figma 里重新运行插件（或点插件菜单里的 Reload plugin）

文件名就是面板里显示的名称，例如 `斜纹-粗.png` 会显示为「斜纹-粗」。

### 对贴图的要求

- **必须正方形**：宽高不相等会被跳过并在终端提示（脚本没法安全地帮你裁切）
- **必须自身无缝**：贴图是整块重复平铺的，接缝处的图案要能首尾接上。
  SVG / PNG 里被边缘切开的图形，平铺后不会自动补到对侧——请让源图自己处理跨界图形
  （参考本目录的 `dot.svg`，四角的圆被切开，平铺后正好拼完整）
- SVG 贴图请在 `<svg>` 上写 `width` / `height`，或至少写 `viewBox`
- 尺寸别太大：贴图尺寸直接决定默认铺贴密度，48~256px 比较合适

### 着色规则（tint）

- `.svg`、带透明通道的 `.png` → 默认「用所选颜色着色」，颜色取插件里的颜色值
- 不带透明通道的 `.jpg` / `.png` → 默认保留原色，面板里出现「着色」开关可手动切换

关闭着色后，颜色选择器会变灰，贴图按自己的颜色铺贴。

### 为什么需要打包脚本

Figma 插件的运行时代码**读不到插件自己的文件夹**：`main` 只能拿到 `code.js`，
UI 只能拿到 `ui.html` 这一个入口文件，相对路径的图片 / 脚本都加载不了。
所以脚本会把图片转成 data URL 内联进 `ui.html`（`<script id="texture-library">`），
并把预设清单写进 `code.js`（`IMAGE_PRESETS`）。这两段都由脚本生成，不要手改。
