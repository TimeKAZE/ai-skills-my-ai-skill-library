# Style Texture

[English](README.md) · **简体中文**

一个 Figma 插件：给选中的 **Frame / 组件** 叠加一层可平铺的纹理，用法接近 PS 图层样式里的「图案叠加」。
内置 **15 种**无缝纹理（网点、斜线、网格、交叉线、竖线、横线、棋盘格、点阵、大圆点、密斜线、虚线、竖虚线、十字纹、锯齿、大方格），也支持两种自定义贴图方式：
面板里 **＋ 导入贴图**（任何分发方式都能用），或把图片放进 `texture/` 后运行打包脚本（仅本地源码版）；
颜色、大小、不透明度、混合模式都可以实时调。面板右上角可切换 **中 / EN**：界面文案和 15 个系统纹理名跟随语言切换，
本地库 / 导入贴图的名字保持原样（文件名即显示名），方便中英文用户共用。

## 安装（本地开发版）

1. 打开 **Figma 桌面版**
2. 菜单 → **Plugins → Development → Import plugin from manifest…**
3. 选择本目录下的 `manifest.json`
4. 之后在 **Plugins → Development → Style Texture** 启动

想先在浏览器里看界面：起一个静态服务后打开 `preview.html`（数据是 mock 的，不参与插件运行）。

```bash
python3 -m http.server 8899
# 打开 http://localhost:8899/preview.html
```

## 使用

1. 在画布上选中一个或多个 **Frame / 组件**
2. 选一种纹理（或点 **＋ 导入贴图** 用自己的图），调颜色、图案大小、不透明度、混合模式
3. 点 **应用纹理**
4. 对同一个 Frame 再次应用只会在原图层上更新参数，不会越叠越多；点 **移除** 可以清掉纹理

应用后的纹理是一层名为 `Style Texture · 网点` 的矩形（英文面板下是 `Style Texture · Dots`），位于 Frame 最上层：

- 尺寸与 Frame 一致，随 Frame 拉伸缩放（`STRETCH` 约束）
- 自动布局的 Frame 里，这层会设为绝对定位，不参与排版
- Frame 有圆角时纹理层跟着圆角
- 上次使用的参数会记住，下次打开插件直接沿用

## 导入贴图（社区版同样可用）

面板「纹理预设」右上角的 **＋ 导入贴图** 支持一次选多张 `.svg` / `.png` / `.jpg` / `.webp`，也可以把图片拖进插件窗口，或直接 <kbd>⌘V</kbd> 粘贴：

- 必须正方形、自身无缝；宽高不等会提示并跳过
- `.svg`、带透明通道的图片默认着色，其余保留原色，可在「用所选颜色着色」开关里切换
- 大图会自动重采样（长边 ≤1024px、WebP/PNG 编码），不用先手动压缩；原图请控制在 8 MB 以内
- 导入成功的贴图出现在灰色分隔线下方的本地库区域（预设多时该区域单独滚动），卡片右上角 × 删除
- 数据存在 `figma.clientStorage`（按用户隔离），上限：单张约 1.5 MB、最多 24 张、总计约 4.5 MB
- 超过上限会提示清理，不影响当次使用，但不会被保存

这条路径不依赖插件目录，所以 **发布到 Figma Community 后同样可用**。

> **关于持久化**：`clientStorage` 要求插件有 ID。`manifest.json` 里没有 `id` 的本地开发版
> 会报 `Cannot access client storage without a plugin ID` —— 此时导入和贴图在本次打开期间
> 完全可用，只是关掉插件后会丢失。解决方法不一定要上架社区：在 Figma 里
> **Plugins → Development → New plugin…** 新建一个插件，把生成的 `id` 填进
> 本项目的 `manifest.json` 再重新导入即可；发布到社区（或创建私有插件）同样会分配 ID。

## 自定义贴图库（texture/ 文件夹，仅源码版）

> Figma 插件运行时读不到自己的文件夹，Community 安装的版本也没有插件目录可放图。
> 这一节只适用于从 GitHub 拉源码、用 `Import plugin from manifest…` 本地安装的版本；
> 社区版请用上面的「导入贴图」。

把图片丢进 **`texture/`**，打包一次，它们就会变成预设卡片。

### 一键打包（不用终端）

| 系统 | 双击这个文件 |
| --- | --- |
| macOS | `build-textures.command` |
| Windows | `build-textures.bat` |

首次使用需要装一次 [Node.js](https://nodejs.org/)（LTS 版本，一路下一步）；脚本会自动检测，
没装会给出提示。macOS 如果提示「无法验证开发者」，**右键点文件 → 打开** 即可。

打包完成后回到 Figma：关掉插件面板，重新启动 **Plugins → Development → Style Texture**。

### 或者用终端

```bash
# 1. 把 .svg / .png / .jpg 放进 texture/
# 2. 打包进插件
node build-textures.js
# 3. 回 Figma 里 Reload plugin
```

- 文件名 = 面板显示名，例如 `斜纹-粗.png` → 「斜纹-粗」
- 必须正方形；宽高不等或尺寸读不出来的文件会被跳过，终端里有提示
- 必须自身无缝：贴图整块重复，接缝处要能接上（参考 `texture/dot.svg`）
- `.svg`、带透明通道的 `.png` 默认用面板里的颜色着色；`.jpg` 默认保留原色，
  面板里会出现「用所选颜色着色」开关，随时切换

> 为什么需要打包：Figma 插件运行时**读不到自己的文件夹**，UI 只能拿到 `ui.html` 一个入口，
> 相对路径的图片加载不了。脚本会把图片转成 data URL 内联进 `ui.html` 的
> `<script id="texture-library">`，并把预设清单写进 `code.js` 的 `IMAGE_PRESETS`。
> 这两段是自动生成的，不要手改。

## 代码里画出来的预设

除了图片，也可以直接在 **`code.js` 顶部的 `TEXTURE_PRESETS` 数组**里用图形拼出预设，
适合线框、网点这类矢量图案（放大不糊）。

```js
const TEXTURE_PRESETS = [
  // ……已有的 15 个预设（网点 / 斜线 / … / 大方格）

  // 例：短横线（虚线）
  {
    id: 'dashes',            // 唯一英文标识
    name: '短横线',          // 中文界面显示名
    nameEn: 'Dashes',        // 英文界面显示名（可省略，省略则沿用 name）
    tile: 24,                // 图案单元边长（逻辑 px）
    shapes: [
      // 12px 实 / 12px 空的横线，上下两行错开，平铺后自动接上
      { type: 'rect', x: 0, y: 6, w: 12, h: 1 },
      { type: 'rect', x: 12, y: 18, w: 12, h: 1 },
    ],
  },
];
```

一个单元（tile 坐标系，左上角为原点）里可以放三种图形：

```js
{ type: 'circle', x: 0, y: 0, r: 3 }                         // 实心圆
{ type: 'rect',   x: 4, y: 4, w: 8, h: 4 }                    // 实心矩形
{ type: 'line',   x1: 0, y1: 0, x2: 16, y2: 0, width: 1 }     // 线段，可加 cap: 'round'
```

每个图形都可以单独加 `color: '#ff0000'`，不写就用用户在面板里选的颜色。

### 无缝平铺是怎么保证的

插件会把单元里的每个图形自动绘制 9 次（`-tile / 0 / +tile` 的偏移组合），越过边缘的部分补到对侧。
所以：

- 图形完全在单元内部 → 天然无缝
- 图形跨过边缘（斜线、贴边网格线）→ 由补绘接上，平铺后仍连续
- 画到角落的圆 → 四个角各补 1/4，拼起来正好是完整圆点

## 文件结构

```
manifest.json            插件清单（无网络权限）
code.js                  主线程：预设清单、选区处理、在 Frame 上创建/更新纹理层
ui.html                  插件界面：预设卡片、贴图生成、实时预览、参数控制
build-textures.js        把 texture/ 里的图片打包进插件（node build-textures.js）
build-textures.command   一键打包（macOS 双击）
build-textures.bat       一键打包（Windows 双击）
texture/                 自定义贴图源文件（svg / png / jpg）+ 使用说明
preview.html             浏览器里预览界面用的 mock 页（不参与插件运行）
intro.html               独立的介绍 / 落地页（用浏览器打开）
intro-en.png / intro-zh.png  intro.html 用的插件面板截图
README.md / README.zh-CN.md  英文 / 中文文档
```

## 实现要点

- 纹理在 UI 的 canvas 里用 2x 分辨率现场生成 PNG（透明底），以 `IMAGE` fill + `scaleMode: 'TILE'`、`scalingFactor: 0.5` 铺回逻辑尺寸，保证细腻且无缝
- 自定义贴图同样缩放到 2x 的 canvas 再导出；着色用 `source-in` 合成，只替换不透明像素，边缘抗锯齿保留
- 同一 Frame 的纹理层用 `pluginData` 标记，重复应用时原地更新而不是新建图层
- 每次应用后把参数（含各贴图的着色开关）存到 `figma.clientStorage`，下次打开沿用
- 面板语言（中 / EN）也跟随参数一起保存；英文名写在系统预设的 `nameEn` 字段，本地 / 导入贴图不翻译
- 只处理 `FRAME` / `COMPONENT`；其它图层会在底部提示中计为「忽略」

## 已知限制

- 只支持 Frame 和组件（普通形状、文字、组不支持）
- 纹理是位图：如果要把 Frame 放到极大画布或高倍导出，可适当调大「图案大小」获得更清晰的边
- 「图案大小」会同时放大纹理的线宽/点径（与 PS 图案缩放的逻辑一致）
- 调整「图案大小」会生成新的贴图资源，相同参数会复用；同一个文件里反复试很多档会多出一些图片资源
- 往 `texture/` 加图后必须重新运行 `node build-textures.js`，插件里才会出现新卡片
- `texture/` 文件夹只对本地源码版有效；Community 版用面板里的「导入贴图」，导入数据受 `clientStorage` 容量限制（单张约 1.5 MB / 最多 24 张 / 总计约 4.5 MB，超出尺寸的图会自动重采样）
