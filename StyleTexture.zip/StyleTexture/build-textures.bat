@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ===========================================
echo   Style Texture - Build custom textures
echo   Style Texture - 打包自定义贴图
echo ===========================================
echo.

where node >nul 2>nul
if errorlevel 1 goto nonode

node build-textures.js
if errorlevel 1 goto failed

echo.
echo [OK] Build finished. / 打包完成。
echo Back in Figma: close the plugin, then reopen Plugins - Development - Style Texture.
echo 回到 Figma：关掉插件面板，再打开 Plugins - Development - Style Texture，
echo 新的贴图会出现在 Textures / 纹理预设 里。
goto end

:nonode
echo [X] Node.js not found. / 没有找到 Node.js。
echo.
echo Building needs Node.js (free). Install it once:
echo   1. Open  https://nodejs.org/
echo   2. Download the LTS build and install it (keep clicking Next)
echo   3. Double-click this file again
echo.
echo 这个打包步骤需要 Node.js（免费软件），安装一次以后都能用：
echo   1. 浏览器打开  https://nodejs.org/
echo   2. 下载 LTS 版本，双击安装（全部下一步即可）
echo   3. 装好后重新双击本文件
goto end

:failed
echo.
echo [X] Build failed. / 打包失败。
echo Please screenshot the messages above. / 请把上面的提示截图发给我。

:end
echo.
pause
