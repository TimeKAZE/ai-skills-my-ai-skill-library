#!/usr/bin/env node
/**
 * 把 texture/ 里的贴图打包进插件。
 *
 * 为什么需要这一步：Figma 插件运行时读不到自己文件夹里的文件 ——
 * main 只会拿到 code.js，UI 只会拿到 ui.html 这一个入口，相对路径的图片加载不了。
 * 所以这里把图片转成 data URL 内联进 ui.html，同时把预设清单写进 code.js。
 *
 * 用法：
 *   node build-textures.js
 *
 * 会重写两段带标记的代码，其余内容不动：
 *   ui.html   <!-- TEXTURE_LIBRARY_START --> … <!-- TEXTURE_LIBRARY_END -->
 *   code.js   /* IMAGE_PRESETS_START *\/ … /* IMAGE_PRESETS_END *\/
 */
'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const TEX_DIR = path.join(ROOT, 'texture');
const UI_FILE = path.join(ROOT, 'ui.html');
const CODE_FILE = path.join(ROOT, 'code.js');

const EXT_MIME = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
};

const UI_START = '<!-- TEXTURE_LIBRARY_START -->';
const UI_END = '<!-- TEXTURE_LIBRARY_END -->';
const CODE_START = '/* IMAGE_PRESETS_START */';
const CODE_END = '/* IMAGE_PRESETS_END */';

function warn(text) {
  console.warn('  ! ' + text);
}

/* ---------------- 读取图片尺寸 ---------------- */

function pngInfo(buf) {
  if (buf.length < 26) return null;
  if (buf.readUInt32BE(0) !== 0x89504e47) return null;
  const width = buf.readUInt32BE(16);
  const height = buf.readUInt32BE(20);
  const colorType = buf[25];
  const hasAlpha = colorType === 4 || colorType === 6 || buf.includes(Buffer.from('tRNS'));
  return { width, height, hasAlpha };
}

function jpegInfo(buf) {
  if (buf.length < 4 || buf[0] !== 0xff || buf[1] !== 0xd8) return null;
  let i = 2;
  while (i + 9 < buf.length) {
    if (buf[i] !== 0xff) {
      i++;
      continue;
    }
    const marker = buf[i + 1];
    if (marker === 0xff) {
      i++;
      continue;
    }
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) {
      i += 2;
      continue;
    }
    if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
      return {
        width: buf.readUInt16BE(i + 7),
        height: buf.readUInt16BE(i + 5),
        hasAlpha: false,
      };
    }
    i += 2 + buf.readUInt16BE(i + 2);
  }
  return null;
}

function svgInfo(text) {
  const attr = (name) => {
    const m = new RegExp('<svg[^>]*\\b' + name + '\\s*=\\s*["\']([\\d.]+)(?:px)?["\']', 'i').exec(text);
    return m ? parseFloat(m[1]) : 0;
  };
  const viewBox = /<svg[^>]*\bviewBox\s*=\s*["']\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)\s*["']/i.exec(text);
  const width = attr('width') || (viewBox ? parseFloat(viewBox[1]) : 0);
  const height = attr('height') || (viewBox ? parseFloat(viewBox[2]) : 0);
  return { width: Math.round(width), height: Math.round(height), hasAlpha: true };
}

function imageInfo(file, ext) {
  const buf = fs.readFileSync(file);
  if (ext === '.png') return pngInfo(buf);
  if (ext === '.jpg' || ext === '.jpeg') return jpegInfo(buf);
  return svgInfo(buf.toString('utf8'));
}

/* ---------------- 生成 id ---------------- */

function shortHash(text) {
  let h = 5381;
  for (let i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) >>> 0;
  return h.toString(36).slice(0, 6);
}

function makeId(baseName, used) {
  const slug = baseName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  let id = 'lib-' + (slug || shortHash(baseName));
  if (used.has(id)) id = id + '-' + shortHash(baseName);
  let n = 2;
  while (used.has(id)) id = id + '-' + n++;
  used.add(id);
  return id;
}

/* ---------------- 收集贴图 ---------------- */

function collect() {
  if (!fs.existsSync(TEX_DIR)) {
    console.error('找不到 texture/ 文件夹：' + TEX_DIR);
    process.exit(1);
  }

  const used = new Set();
  const presets = [];

  const files = fs
    .readdirSync(TEX_DIR)
    .filter((name) => EXT_MIME[path.extname(name).toLowerCase()])
    .sort((a, b) => a.localeCompare(b, 'zh-Hans-CN'));

  for (const name of files) {
    const ext = path.extname(name).toLowerCase();
    const file = path.join(TEX_DIR, name);
    const baseName = name.slice(0, -ext.length);

    if (!fs.statSync(file).isFile()) continue;

    const info = imageInfo(file, ext);
    if (!info || !info.width || !info.height) {
      warn(name + '：读不出尺寸，已跳过');
      continue;
    }
    if (info.width !== info.height) {
      warn(name + '：不是正方形（' + info.width + '×' + info.height + '），已跳过');
      continue;
    }
    if (info.width < 8) {
      warn(name + '：尺寸太小（' + info.width + 'px），已跳过');
      continue;
    }

    const dataUrl = 'data:' + EXT_MIME[ext] + ';base64,' + fs.readFileSync(file).toString('base64');

    presets.push({
      id: makeId(baseName, used),
      name: baseName,
      tile: info.width,
      src: 'texture/' + name,
      tint: ext === '.svg' ? true : info.hasAlpha,
      dataUrl,
    });
  }

  return presets;
}

/* ---------------- 写回文件 ---------------- */

function buildUiBlock(presets) {
  const lines = presets.map(function (p) {
    const entry = {
      id: p.id,
      name: p.name,
      tile: p.tile,
      src: p.src,
      tint: p.tint,
      dataUrl: p.dataUrl,
    };
    return '  ' + JSON.stringify(entry);
  });

  const json = '{"presets": [\n' + lines.join(',\n') + '\n]}';

  return [
    '<script id="texture-library" type="application/json">',
    // 转义 <，避免任何文件名 / 内容意外闭合 script 标签
    json.replace(/</g, '\\u003c'),
    '</script>',
  ].join('\n');
}

function buildCodeBlock(presets) {
  const lines = presets.map(function (p) {
    return (
      '  { id: ' + JSON.stringify(p.id) +
      ', name: ' + JSON.stringify(p.name) +
      ', tile: ' + p.tile +
      ', texture: ' + JSON.stringify(p.src) +
      ', tint: ' + (p.tint ? 'true' : 'false') + ' },'
    );
  });

  return [
    '// 由 build-textures.js 自动生成，请勿手改（往 texture/ 里丢图后运行 node build-textures.js）',
    'const IMAGE_PRESETS = [',
    lines.join('\n'),
    '];',
  ].join('\n');
}

function replaceBlock(file, startMarker, endMarker, body) {
  const src = fs.readFileSync(file, 'utf8');
  const start = src.indexOf(startMarker);
  const end = src.indexOf(endMarker);

  if (start < 0 || end < 0 || end < start) {
    console.error(path.basename(file) + ' 里找不到标记：' + startMarker + ' / ' + endMarker);
    process.exit(1);
  }

  const head = src.slice(0, start + startMarker.length);
  const tail = src.slice(end);
  fs.writeFileSync(file, head + '\n' + body + '\n' + tail, 'utf8');
}

/* ---------------- main ---------------- */

const presets = collect();

replaceBlock(UI_FILE, UI_START, UI_END, buildUiBlock(presets));
replaceBlock(CODE_FILE, CODE_START, CODE_END, buildCodeBlock(presets));

const totalBytes = presets.reduce((sum, p) => sum + p.dataUrl.length, 0);

console.log('已打包 ' + presets.length + ' 张自定义贴图（内联后约 ' + Math.round(totalBytes / 1024) + ' KB）');
presets.forEach(function (p) {
  console.log('  · ' + p.name + '  ' + p.tile + '×' + p.tile + '  →  ' + p.id);
});
if (!presets.length) {
  console.log('  （texture/ 里还没有可用的贴图）');
}
