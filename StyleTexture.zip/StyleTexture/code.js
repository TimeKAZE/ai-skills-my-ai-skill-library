/**
 * Style Texture — 图案叠加（Pattern Overlay）
 * Figma Plugin · main thread
 *
 * 思路与 PS「图层样式 → 图案叠加」一致：
 * - 在选中的 Frame / 组件里放一层与底板等大的矩形，填充无缝纹理贴图（tile 平铺）
 * - 纹理用 UI 里的 canvas 现场生成，透明底 + 3×3 循环补绘，因此平铺后图案保持连续
 * - 同一 Frame 只保留一层纹理，换预设 / 换颜色 / 换尺寸都是原地更新，不会叠出一堆图层
 */

/* ============================================================
 * 预设纹理 —— 想加新纹理，直接往这个数组里加一项即可
 * ------------------------------------------------------------
 * 字段：
 *   id      唯一英文标识（用于记录与更新图层，不要重复）
 *   name    面板里显示的名称（中文）
 *   nameEn  英文面板里显示的名称（省略则沿用 name；本地贴图不需要填）
 *   tile    一个图案单元的边长（逻辑 px），也决定默认密度
 *   shapes  图案单元内的图形，坐标以左上角为原点的 tile 坐标系
 *
 * shapes 支持三种图形：
 *   { type: 'circle', x, y, r }                  实心圆
 *   { type: 'rect',   x, y, w, h }               实心矩形
 *   { type: 'line',   x1, y1, x2, y2, width }    线段（可加 cap: 'round'）
 *   任意图形都可以加 color: '#ff0000' 覆盖用户选择的颜色
 *
 * 无缝原理：每个图形都会被自动绘制 9 次（-tile / 0 / +tile 的偏移组合），
 * 越过边缘的部分会被补到对侧，所以只要图形在 tile 边界处首尾相接，平铺后就无缝。
 * 例：45° 斜线用来回穿过角落的线段，网格用贴边的横竖线，都会自动接上。
 * ============================================================ */
const TEXTURE_PRESETS = [
  {
    id: 'dots',
    name: '网点',
    nameEn: 'Dots',
    tile: 24,
    shapes: [
      { type: 'circle', x: 0, y: 0, r: 3 },
      { type: 'circle', x: 12, y: 12, r: 3 },
    ],
  },
  {
    id: 'diagonal',
    name: '斜线',
    nameEn: 'Diagonal',
    tile: 24,
    shapes: [
      // y = -x + 12 的 45° 斜线，跨过整个 tile，四周补齐后连成一条条平行线
      { type: 'line', x1: -24, y1: 36, x2: 36, y2: -24, width: 1 },
    ],
  },
  {
    id: 'grid',
    name: '网格',
    nameEn: 'Grid',
    tile: 16,
    shapes: [
      { type: 'line', x1: 0, y1: 0, x2: 0, y2: 16, width: 1 },
      { type: 'line', x1: 0, y1: 0, x2: 16, y2: 0, width: 1 },
    ],
  },
  {
    id: 'crosshatch',
    name: '交叉线',
    nameEn: 'X-hatch',
    tile: 24,
    shapes: [
      // 正反两组 45° 线（y = -x + 12 / y = x + 12）交叉成菱形网
      { type: 'line', x1: -24, y1: 36, x2: 36, y2: -24, width: 1 },
      { type: 'line', x1: -24, y1: -12, x2: 36, y2: 48, width: 1 },
    ],
  },
  {
    id: 'vertical',
    name: '竖线',
    nameEn: 'Vertical',
    tile: 24,
    shapes: [
      // 1px 竖线，间距与「斜线」一致
      { type: 'line', x1: 0, y1: 0, x2: 0, y2: 24, width: 1 },
    ],
  },
  {
    id: 'horizontal',
    name: '横线',
    nameEn: 'Horiz.',
    tile: 24,
    shapes: [
      // 1px 横线，与「竖线」互为转置
      { type: 'line', x1: 0, y1: 0, x2: 24, y2: 0, width: 1 },
    ],
  },
  {
    id: 'checker',
    name: '棋盘格',
    nameEn: 'Checker',
    tile: 20,
    shapes: [
      // 10×10 的方格，对角各一个，平铺后交错成棋盘
      { type: 'rect', x: 0, y: 0, w: 10, h: 10 },
      { type: 'rect', x: 10, y: 10, w: 10, h: 10 },
    ],
  },
  {
    id: 'dot-grid',
    name: '点阵',
    nameEn: 'Dot grid',
    tile: 16,
    shapes: [
      // 圆放在 tile 角落，平铺后四个 1/4 圆拼成一颗，得到对齐的点阵
      { type: 'circle', x: 0, y: 0, r: 2 },
    ],
  },
  {
    id: 'dots-large',
    name: '大圆点',
    nameEn: 'Big dots',
    tile: 28,
    shapes: [
      { type: 'circle', x: 0, y: 0, r: 5 },
      { type: 'circle', x: 14, y: 14, r: 5 },
    ],
  },
  {
    id: 'diagonal-dense',
    name: '密斜线',
    nameEn: 'Dense',
    tile: 12,
    shapes: [
      // 同 45° 斜线，但单元更小、线距更密
      { type: 'line', x1: -12, y1: 18, x2: 18, y2: -12, width: 1 },
    ],
  },
  {
    id: 'dash-h',
    name: '虚线',
    nameEn: 'Dashes',
    tile: 24,
    shapes: [
      // 12px 实、12px 空，隔行错开半格
      { type: 'rect', x: 0, y: 0, w: 12, h: 1 },
      { type: 'rect', x: 12, y: 12, w: 12, h: 1 },
    ],
  },
  {
    id: 'dash-v',
    name: '竖虚线',
    nameEn: 'V. dashes',
    tile: 24,
    shapes: [
      { type: 'rect', x: 0, y: 0, w: 1, h: 12 },
      { type: 'rect', x: 12, y: 12, w: 1, h: 12 },
    ],
  },
  {
    id: 'cross',
    name: '十字纹',
    nameEn: 'Crosses',
    tile: 20,
    shapes: [
      // 2px 粗的横竖短线组成「＋」，格与格之间留 4px 空隙
      { type: 'rect', x: 2, y: 9, w: 16, h: 2 },
      { type: 'rect', x: 9, y: 2, w: 2, h: 16 },
    ],
  },
  {
    id: 'zigzag',
    name: '锯齿',
    nameEn: 'Zigzag',
    tile: 16,
    shapes: [
      // /\ 两段 45° 线在 tile 边界处相接，连成一条条横向锯齿带
      { type: 'line', x1: 0, y1: 8, x2: 8, y2: 0, width: 1 },
      { type: 'line', x1: 8, y1: 0, x2: 16, y2: 8, width: 1 },
    ],
  },
  {
    id: 'grid-large',
    name: '大方格',
    nameEn: 'Big grid',
    tile: 32,
    shapes: [
      { type: 'line', x1: 0, y1: 0, x2: 0, y2: 32, width: 1 },
      { type: 'line', x1: 0, y1: 0, x2: 32, y2: 0, width: 1 },
    ],
  },
];

/* ============================================================
 * 自定义贴图库 —— 往 texture/ 文件夹里丢图，运行 node build-textures.js
 * ------------------------------------------------------------
 * 下面这段由脚本自动生成：
 *   id      自动生成的唯一标识（lib- 前缀）
 *   name    文件名（不含扩展名）
 *   tile    贴图边长，等宽高
 *   texture 源文件路径（只在脚本里有意义，插件运行时用不到）
 *   tint    默认是否用用户选的颜色着色
 * 图片数据本身内联在 ui.html 的 <script id="texture-library"> 里。
 * ============================================================ */
/* IMAGE_PRESETS_START */
// 由 build-textures.js 自动生成，请勿手改（往 texture/ 里丢图后运行 node build-textures.js）
const IMAGE_PRESETS = [
  { id: "lib-yccilf", name: "示例-圆点网格", tile: 48, texture: "texture/示例-圆点网格.svg", tint: true },
  { id: "lib-dog", name: "dog", tile: 200, texture: "texture/dog.svg", tint: true },
];
/* IMAGE_PRESETS_END */

const ALL_PRESETS = TEXTURE_PRESETS.concat(IMAGE_PRESETS);

const PRESETS_BY_ID = {};
ALL_PRESETS.forEach(function (p) { PRESETS_BY_ID[p.id] = p; });

const OVERLAY_KEY = 'styleTexturePreset';
const SETTINGS_KEY = 'style-texture-settings';
const IMPORTS_KEY = 'style-texture-imports';
const BLEND_MODES = ['NORMAL', 'MULTIPLY', 'SCREEN', 'OVERLAY', 'SOFT_LIGHT', 'DARKEN', 'LIGHTEN'];
const IMAGE_CACHE = new Map();

// 面板语言（由 UI 同步过来）：只影响本插件自己写的提示、报错和纹理层名字，
// 用户自己的 Frame / 贴图名字一律不动。
var currentLang = 'zh';
var cachedSettings = null;

function tr(zh, en) {
  return currentLang === 'en' ? en : zh;
}

function presetLabel(preset) {
  return currentLang === 'en' && preset.nameEn ? preset.nameEn : preset.name;
}

// UI 里「导入贴图」进来的预设：数据存在 clientStorage，主线程按 id 查名字
const IMPORTED_BY_ID = Object.create(null);

// UI 侧会把大图重采样到 ≤1024px / ≤1.5MB 再发过来，这里做最终兜底
const IMPORT_LIMITS = {
  count: 24,
  itemBytes: 1.5 * 1024 * 1024,
  totalBytes: 4.5 * 1024 * 1024,
};

figma.showUI(__html__, {
  width: 352,
  height: 648,
  themeColors: true,
});

figma.ui.onmessage = function (msg) {
  if (!msg || typeof msg.type !== 'string') return;

  if (msg.type === 'ready') {
    onReady();
  } else if (msg.type === 'apply') {
    applyTexture(msg).catch(reportError);
  } else if (msg.type === 'remove') {
    removeTexture().catch(reportError);
  } else if (msg.type === 'save-imports') {
    saveImports(msg.imports).catch(reportError);
  } else if (msg.type === 'lang') {
    setLang(msg.lang);
  } else if (msg.type === 'resize') {
    resizeUI(msg);
  }
};

function resizeUI(msg) {
  var height = Math.round(Number(msg.height) || 0);
  var width = Math.round(Number(msg.width) || 352);
  if (!(height > 0) || typeof figma.ui.resize !== 'function') return;
  try {
    figma.ui.resize(width, Math.max(360, Math.min(height, 1600)));
  } catch (e) {
    /* 窗口高度受编辑器限制时忽略，UI 会自动退回滚动 */
  }
}

figma.on('selectionchange', function () {
  post({ type: 'selection', selection: selectionInfo() });
});

function post(payload) {
  try {
    figma.ui.postMessage(payload);
  } catch (e) {
    /* UI 已关闭 */
  }
}

function reportError(err) {
  post({
    type: 'error',
    message: err && err.message ? err.message : String(err),
  });
}

function clampNumber(value, min, max, fallback) {
  var n = Number(value);
  if (!isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

/* ------------------------------------------------------------------ *
 * 初始化
 * ------------------------------------------------------------------ */

async function onReady() {
  var settings = null;
  try {
    settings = await figma.clientStorage.getAsync(SETTINGS_KEY);
  } catch (e) {
    settings = null;
  }

  cachedSettings = settings && typeof settings === 'object' ? settings : {};
  currentLang = cachedSettings.lang === 'en' ? 'en' : 'zh';

  var imports = [];
  try {
    imports = sanitizeImports(await figma.clientStorage.getAsync(IMPORTS_KEY));
  } catch (e) {
    imports = [];
  }

  resetImportedMap(imports);

  post({
    type: 'init',
    presets: ALL_PRESETS.map(function (p) {
      return {
        id: p.id,
        name: p.name,
        nameEn: p.nameEn || null,
        tile: p.tile,
        shapes: p.shapes || null,
        kind: p.shapes ? 'shape' : 'image',
        texture: p.texture || null,
        tint: typeof p.tint === 'boolean' ? p.tint : null,
      };
    }),
    imports: imports,
    settings: settings,
    selection: selectionInfo(),
  });
}

function sanitizeImports(list) {
  if (!Array.isArray(list)) return [];
  var out = [];
  for (var i = 0; i < list.length && out.length < IMPORT_LIMITS.count; i++) {
    var item = list[i];
    if (!item || typeof item.id !== 'string' || !item.id) continue;
    if (typeof item.dataUrl !== 'string' || item.dataUrl.indexOf('data:image/') !== 0) continue;
    if (item.dataUrl.length > IMPORT_LIMITS.itemBytes) continue;
    var tile = Math.round(Number(item.tile));
    if (!isFinite(tile) || tile < 8) continue;
    out.push({
      id: item.id,
      name: typeof item.name === 'string' && item.name ? item.name : tr('导入贴图', 'Imported texture'),
      tile: tile,
      tint: item.tint === true,
      dataUrl: item.dataUrl,
    });
  }
  return out;
}

function resetImportedMap(imports) {
  Object.keys(IMPORTED_BY_ID).forEach(function (id) { delete IMPORTED_BY_ID[id]; });
  imports.forEach(function (item) { IMPORTED_BY_ID[item.id] = item; });
}

async function saveImports(list) {
  var imports = sanitizeImports(list);
  var serialized = JSON.stringify(imports);

  // 先认下这批贴图：应用只依赖这张内存表，不依赖持久化。
  // 没有 plugin ID 的本地开发版拿不到 clientStorage，但本次会话里仍要能贴。
  resetImportedMap(imports);

  if (serialized.length > IMPORT_LIMITS.totalBytes) {
    var limitKb = Math.round(IMPORT_LIMITS.totalBytes / 1024);
    post({
      type: 'imports-saved',
      ok: false,
      message: tr(
        '存储空间不够：导入的贴图总量超过 ' + limitKb + ' KB，请先删掉几张再导入',
        'Not enough storage: imported textures exceed ' + limitKb +
          ' KB in total — delete a few, then import again'
      ),
    });
    return;
  }

  try {
    await figma.clientStorage.setAsync(IMPORTS_KEY, imports);
  } catch (e) {
    var detail = e && e.message ? e.message : String(e);
    var noId = /plugin ID/i.test(detail);
    post({
      type: 'imports-saved',
      ok: false,
      reason: noId ? 'no-plugin-id' : 'storage',
      message: noId
        ? tr(
            '贴图已导入，本次打开可用，但不会保存：插件缺少 ID',
            'Textures imported and usable this session, but not saved: the plugin has no ID'
          )
        : tr('保存失败：', 'Save failed: ') + detail,
    });
    return;
  }

  post({ type: 'imports-saved', ok: true, count: imports.length });
}

function targetFrames() {
  return figma.currentPage.selection.filter(function (node) {
    return node.type === 'FRAME' || node.type === 'COMPONENT';
  });
}

function selectionInfo() {
  var all = figma.currentPage.selection;
  var frames = [];
  var skipped = 0;

  for (var i = 0; i < all.length; i++) {
    var node = all[i];
    if (node.type === 'FRAME' || node.type === 'COMPONENT') {
      frames.push({ id: node.id, name: node.name });
    } else {
      skipped++;
    }
  }
  return { frames: frames, skipped: skipped };
}

/* ------------------------------------------------------------------ *
 * 应用纹理
 * ------------------------------------------------------------------ */

async function applyTexture(msg) {
  var preset = PRESETS_BY_ID[msg.presetId] || IMPORTED_BY_ID[msg.presetId];
  if (!preset) throw new Error(tr('找不到纹理预设：', 'Texture preset not found: ') + msg.presetId);

  var targets = targetFrames();
  if (!targets.length) {
    post({ type: 'applied', ok: 0, fail: 0, empty: true, presetName: presetLabel(preset) });
    figma.notify(
      tr('Style Texture：请先选择至少一个 Frame 或组件', 'Style Texture: Select at least one Frame or component first'),
      { error: true }
    );
    return;
  }

  var base64 = String(msg.tileBase64 || '');
  if (!base64) throw new Error(tr('纹理贴图生成失败', 'Couldn’t generate the texture tile'));

  var color = typeof msg.color === 'string' ? msg.color : '#000000';
  var blendMode = BLEND_MODES.indexOf(msg.blendMode) >= 0 ? msg.blendMode : 'NORMAL';
  var opacity = clampNumber(msg.opacity, 0, 1, 1);
  var scaleFactor = clampNumber(msg.scaleFactor, 0.01, 10, 0.5);

  var image = getImage(preset, color, msg.scale, base64);

  var ok = 0;
  var failed = 0;
  var errors = [];

  for (var i = 0; i < targets.length; i++) {
    try {
      upsertOverlay(targets[i], preset, image.hash, {
        blendMode: blendMode,
        opacity: opacity,
        scaleFactor: scaleFactor,
      });
      ok++;
    } catch (e) {
      failed++;
      var detail = e && e.message ? e.message : String(e);
      errors.push({ frame: targets[i].name, message: detail });
      try {
        console.error('[Style Texture] ' + targets[i].name + '：' + detail, e);
      } catch (logErr) {
        /* ignore */
      }
    }
  }

  saveSettings(msg);

  post({ type: 'applied', ok: ok, fail: failed, errors: errors, presetName: presetLabel(preset) });

  if (failed > 0 && errors.length) {
    if (ok === 0) {
      figma.notify(tr('Style Texture：应用失败 — ', 'Style Texture: Apply failed — ') + errors[0].message, {
        error: true,
        timeout: 5000,
      });
    } else {
      figma.notify(
        tr(
          'Style Texture：已应用 ' + ok + ' 个，' + failed + ' 个失败（' + errors[0].message + '）',
          'Style Texture: Applied to ' + ok + ', ' + failed + ' failed (' + errors[0].message + ')'
        ),
        { timeout: 4000 }
      );
    }
  } else {
    figma.notify(
      tr(
        'Style Texture：已应用「' + presetLabel(preset) + '」到 ' + ok + ' 个 Frame',
        'Style Texture: Applied “' + presetLabel(preset) + '” to ' + ok + ' Frame(s)'
      ),
      { timeout: 2500 }
    );
  }
}

/**
 * 同一组参数复用同一张 Figma Image，避免滑一下滑块就往文件里塞一张新图。
 * scaleFactor 由 UI 按「逻辑图案尺寸 / 贴图像素数」算出，通常就是 0.5（2x 贴图）。
 */
function getImage(preset, color, uiScale, base64) {
  var key = [preset.id, color, uiScale, hashString(base64)].join('|');
  var cached = IMAGE_CACHE.get(key);
  if (cached) return cached;

  var bytes = decodeBase64(base64);
  if (!bytes || !bytes.length) throw new Error(tr('纹理贴图生成失败', 'Couldn’t generate the texture tile'));

  var image = figma.createImage(bytes);
  IMAGE_CACHE.set(key, image);
  return image;
}

function hashString(text) {
  var h = 5381;
  for (var i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) >>> 0;
  return h.toString(36);
}

function decodeBase64(base64) {
  if (typeof figma.base64Decode === 'function') {
    return figma.base64Decode(base64);
  }
  var binary = atob(base64);
  var bytes = new Uint8Array(binary.length);
  for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

// 没有 plugin ID 的本地开发版连 pluginData 都读不了，
// 所以标记失效时退回按图层名识别（名字是本插件自己起的）
const OVERLAY_NAME_PREFIX = 'Style Texture · ';

function hasOverlayMark(node) {
  try {
    return !!node.getPluginData(OVERLAY_KEY);
  } catch (e) {
    return false;
  }
}

function isOverlayNode(node) {
  if (!node || node.type !== 'RECTANGLE') return false;
  if (hasOverlayMark(node)) return true;
  return typeof node.name === 'string' && node.name.indexOf(OVERLAY_NAME_PREFIX) === 0;
}

function findOverlay(frame) {
  var children = frame.children || [];
  for (var i = 0; i < children.length; i++) {
    if (isOverlayNode(children[i])) return children[i];
  }
  return null;
}

function assertEditable(frame) {
  if (frame.locked) throw new Error(tr('图层已锁定，请先解锁', 'The layer is locked — unlock it first'));

  var parent = frame.parent;
  while (parent && parent.type !== 'PAGE' && parent.type !== 'DOCUMENT') {
    if (parent.type === 'INSTANCE') {
      throw new Error(
        tr(
          '图层在组件实例内部，Figma 不允许往里加图层',
          'This layer is inside a component instance — Figma doesn’t allow adding layers there'
        )
      );
    }
    if (parent.locked) {
      throw new Error(tr('所在父级已锁定，请先解锁', 'A parent layer is locked — unlock it first'));
    }
    parent = parent.parent;
  }
}

function wrapError(label, err) {
  var detail = err && err.message ? err.message : String(err);
  return new Error(label + tr('：', ': ') + detail);
}

function upsertOverlay(frame, preset, imageHash, opts) {
  assertEditable(frame);

  var overlay = findOverlay(frame);
  if (!overlay) overlay = figma.createRectangle();

  // appendChild 会把已有图层挪到最后，保证纹理始终盖在内容之上
  try {
    frame.appendChild(overlay);
  } catch (e) {
    throw wrapError(tr('无法把纹理层放进这个 Frame', 'Couldn’t add the texture layer to this Frame'), e);
  }

  overlay.name = OVERLAY_NAME_PREFIX + presetLabel(preset);

  try {
    overlay.fills = [
      {
        type: 'IMAGE',
        imageHash: imageHash,
        scaleMode: 'TILE',
        scalingFactor: opts.scaleFactor,
      },
    ];
  } catch (e) {
    throw wrapError(tr('无法设置平铺填充', 'Couldn’t set the tiled fill'), e);
  }

  // 下面这些是锦上添花，单独失败不影响纹理本身
  try { overlay.blendMode = opts.blendMode; } catch (e) { /* ignore */ }
  try { overlay.opacity = opts.opacity; } catch (e) { /* ignore */ }
  try { overlay.constraints = { horizontal: 'STRETCH', vertical: 'STRETCH' }; } catch (e) { /* ignore */ }
  try { overlay.visible = true; } catch (e) { /* ignore */ }
  try { overlay.locked = false; } catch (e) { /* ignore */ }

  var isAutoLayout = frame.layoutMode && frame.layoutMode !== 'NONE';
  if (isAutoLayout) {
    try {
      overlay.layoutPositioning = 'ABSOLUTE';
    } catch (e) {
      throw wrapError(
        tr('无法在自动布局里把纹理层设为绝对定位', 'Couldn’t make the texture layer absolute inside auto layout'),
        e
      );
    }
  }

  try {
    overlay.x = 0;
    overlay.y = 0;
  } catch (e) {
    throw wrapError(tr('无法设置纹理层位置', 'Couldn’t position the texture layer'), e);
  }

  try {
    overlay.resize(Math.max(frame.width, 0.01), Math.max(frame.height, 0.01));
  } catch (e) {
    throw wrapError(tr('无法调整纹理层尺寸', 'Couldn’t resize the texture layer'), e);
  }

  copyCornerRadius(frame, overlay);

  try {
    overlay.setPluginData(OVERLAY_KEY, preset.id);
  } catch (e) {
    /* ignore */
  }
}

function copyCornerRadius(frame, overlay) {
  try {
    if (typeof frame.cornerRadius === 'number') {
      overlay.cornerRadius = frame.cornerRadius;
      return;
    }
    var radii = [
      frame.topLeftRadius,
      frame.topRightRadius,
      frame.bottomRightRadius,
      frame.bottomLeftRadius,
    ];
    for (var i = 0; i < radii.length; i++) {
      if (typeof radii[i] !== 'number') return;
    }
    overlay.topLeftRadius = radii[0];
    overlay.topRightRadius = radii[1];
    overlay.bottomRightRadius = radii[2];
    overlay.bottomLeftRadius = radii[3];
  } catch (e) {
    /* 没有圆角属性的节点直接跳过 */
  }
}

/* ------------------------------------------------------------------ *
 * 移除纹理
 * ------------------------------------------------------------------ */

async function removeTexture() {
  var targets = targetFrames();
  if (!targets.length) {
    post({ type: 'removed', ok: 0 });
    figma.notify(
      tr('Style Texture：请先选择 Frame 或组件', 'Style Texture: Select a Frame or component first'),
      { error: true }
    );
    return;
  }

  var ok = 0;
  var failed = 0;

  for (var i = 0; i < targets.length; i++) {
    var frame = targets[i];
    var overlays = (frame.children || []).filter(isOverlayNode);
    if (!overlays.length) continue;

    try {
      for (var j = 0; j < overlays.length; j++) overlays[j].remove();
      ok++;
    } catch (e) {
      failed++;
    }
  }

  post({ type: 'removed', ok: ok, fail: failed });

  if (ok > 0) {
    figma.notify(
      tr(
        'Style Texture：已移除 ' + ok + ' 个 Frame 上的纹理',
        'Style Texture: Removed textures from ' + ok + ' Frame(s)'
      ),
      { timeout: 2200 }
    );
  } else {
    figma.notify(
      tr('Style Texture：选中的 Frame 上没有纹理', 'Style Texture: The selected Frames have no texture'),
      { timeout: 2200 }
    );
  }
}

/* ------------------------------------------------------------------ *
 * 记录上次使用的参数
 * ------------------------------------------------------------------ */

function persistSettings(patch) {
  cachedSettings = Object.assign({}, cachedSettings || {}, patch);
  figma.clientStorage.setAsync(SETTINGS_KEY, cachedSettings).catch(function () {
    /* 存储失败不影响主流程 */
  });
}

function saveSettings(msg) {
  persistSettings({
    presetId: msg.presetId,
    color: msg.color,
    scale: msg.scale,
    opacity: msg.opacity,
    blendMode: msg.blendMode,
    tints: msg.tints && typeof msg.tints === 'object' ? msg.tints : {},
  });
}

function setLang(lang) {
  currentLang = lang === 'en' ? 'en' : 'zh';
  persistSettings({ lang: currentLang });
}